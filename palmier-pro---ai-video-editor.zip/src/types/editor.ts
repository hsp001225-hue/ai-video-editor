export type MediaType = 'video' | 'audio' | 'image' | 'text';

export interface MediaAsset {
  id: string;
  name: string;
  type: MediaType;
  url: string;
  duration: number; // in seconds
  width?: number;
  height?: number;
  thumbnail?: string;
  sizeBytes?: number;
  blob?: Blob;
}

export interface Transform {
  x: number; // offset X from center in pixels or percentage
  y: number; // offset Y from center
  scale: number; // 0.1 to 5.0
  rotation: number; // in degrees -180 to 180
  opacity: number; // 0.0 to 1.0
}

export interface VideoFilters {
  brightness: number; // 0 to 200, default 100
  contrast: number; // 0 to 200, default 100
  saturation: number; // 0 to 200, default 100
  blur: number; // 0 to 20 px, default 0
  sepia: number; // 0 to 100%, default 0
  grayscale: number; // 0 to 100%, default 0
}

export interface TextConfig {
  text: string;
  fontSize: number;
  fontFamily: string;
  fontWeight: 'normal' | '500' | '600' | 'bold' | '900';
  color: string;
  backgroundColor?: string;
  textAlign: 'left' | 'center' | 'right';
  strokeColor?: string;
  strokeWidth?: number;
  shadow?: boolean;
}

export interface ClipTransition {
  type: 'fade' | 'dissolve' | 'wipe' | 'slide' | 'zoom';
  duration: number; // seconds
  position: 'in' | 'out' | 'both';
}

export interface TimelineClip {
  id: string;
  trackId: string;
  assetId?: string;
  type: MediaType;
  name: string;
  startTime: number; // timeline time when clip starts (seconds)
  duration: number; // active duration in timeline (seconds)
  trimIn: number; // start offset within media asset (seconds)
  trimOut: number; // end offset within media asset (seconds)
  speed: number; // 0.25 to 4.0
  volume: number; // 0.0 to 2.0 (1.0 = 100%)
  muted: boolean;
  transform: Transform;
  filters: VideoFilters;
  textConfig?: TextConfig;
  transition?: ClipTransition;
  color?: string; // UI pill color
}

export interface TimelineTrack {
  id: string;
  name: string;
  type: 'video' | 'audio' | 'overlay';
  muted: boolean;
  locked: boolean;
  hidden: boolean;
  volume: number;
}

export interface TimelineMarker {
  id: string;
  time: number; // seconds
  label: string;
  color: string;
}

export type AspectRatioType = '16:9' | '9:16' | '1:1' | '4:5' | '21:9';

export interface ProjectSettings {
  name: string;
  width: number;
  height: number;
  fps: number;
  duration: number; // in seconds
  aspectRatio: AspectRatioType;
  backgroundColor: string;
  snapTolerance: number; // in seconds
}

export interface HistoryState {
  tracks: TimelineTrack[];
  clips: TimelineClip[];
  markers: TimelineMarker[];
  projectSettings: ProjectSettings;
}

export interface ExportConfig {
  resolution: '720p' | '1080p' | '4k';
  width: number;
  height: number;
  fps: 24 | 30 | 60;
  format: 'mp4' | 'webm';
  quality: 'draft' | 'standard' | 'high';
}

// ==========================================
// STRUCTURED AI EDITING COMMAND SPECIFICATION
// ==========================================

export type SupportedCommandType =
  | 'add_clip'
  | 'remove_clip'
  | 'trim_clip'
  | 'split_clip'
  | 'move_clip'
  | 'resize_clip'
  | 'change_volume'
  | 'change_speed'
  | 'add_transition'
  | 'add_text'
  | 'add_audio'
  | 'add_marker'
  | 'change_aspect_ratio'
  | 'undo'
  | 'redo';

export interface BaseCommand {
  id?: string;
  type: SupportedCommandType;
  description?: string;
}

export interface AddClipCommand extends BaseCommand {
  type: 'add_clip';
  assetId?: string;
  name?: string;
  trackId?: string;
  startTime: number;
  duration?: number;
}

export interface RemoveClipCommand extends BaseCommand {
  type: 'remove_clip';
  clipId: string;
}

export interface TrimClipCommand extends BaseCommand {
  type: 'trim_clip';
  clipId: string;
  trimIn?: number;
  trimOut?: number;
  startTime?: number;
  duration?: number;
}

export interface SplitClipCommand extends BaseCommand {
  type: 'split_clip';
  clipId: string;
  splitTime?: number;
}

export interface MoveClipCommand extends BaseCommand {
  type: 'move_clip';
  clipId: string;
  startTime: number;
  trackId?: string;
}

export interface ResizeClipCommand extends BaseCommand {
  type: 'resize_clip';
  clipId: string;
  duration?: number;
  scale?: number;
}

export interface ChangeVolumeCommand extends BaseCommand {
  type: 'change_volume';
  clipId: string;
  volume: number; // 0.0 to 2.0
}

export interface ChangeSpeedCommand extends BaseCommand {
  type: 'change_speed';
  clipId: string;
  speed: number; // 0.25 to 4.0
}

export interface AddTransitionCommand extends BaseCommand {
  type: 'add_transition';
  clipId: string;
  transitionType: 'fade' | 'dissolve' | 'wipe' | 'slide' | 'zoom';
  duration?: number; // seconds
  position?: 'in' | 'out' | 'both';
}

export interface AddTextCommand extends BaseCommand {
  type: 'add_text';
  text: string;
  startTime?: number;
  duration?: number;
  trackId?: string;
  fontSize?: number;
  color?: string;
  backgroundColor?: string;
  positionY?: number;
}

export interface AddAudioCommand extends BaseCommand {
  type: 'add_audio';
  assetId?: string;
  trackId?: string;
  startTime?: number;
  duration?: number;
  volume?: number;
}

export interface AddMarkerCommand extends BaseCommand {
  type: 'add_marker';
  time: number;
  label: string;
  color?: string;
}

export interface ChangeAspectRatioCommand extends BaseCommand {
  type: 'change_aspect_ratio';
  aspectRatio: AspectRatioType;
}

export interface UndoCommand extends BaseCommand {
  type: 'undo';
}

export interface RedoCommand extends BaseCommand {
  type: 'redo';
}

export type EditingCommand =
  | AddClipCommand
  | RemoveClipCommand
  | TrimClipCommand
  | SplitClipCommand
  | MoveClipCommand
  | ResizeClipCommand
  | ChangeVolumeCommand
  | ChangeSpeedCommand
  | AddTransitionCommand
  | AddTextCommand
  | AddAudioCommand
  | AddMarkerCommand
  | ChangeAspectRatioCommand
  | UndoCommand
  | RedoCommand;

export interface CommandValidationResult {
  valid: boolean;
  command: EditingCommand;
  errors: string[];
  warnings: string[];
  previewDescription: string;
}

export interface ParsedCommandPlan {
  id: string;
  userPrompt: string;
  explanation: string;
  commands: EditingCommand[];
  validationResults: CommandValidationResult[];
  timestamp: number;
}

export interface CommandExecutionResult {
  success: boolean;
  commandType: SupportedCommandType;
  message: string;
  error?: string;
  affectedClipId?: string;
}
