import React from 'react';
import {
  Sliders,
  Move,
  RotateCw,
  Eye,
  Volume2,
  Gauge,
  Scissors,
  Copy,
  Trash2,
  Sparkles,
  Type,
  Maximize,
  RotateCcw,
} from 'lucide-react';
import { useEditorStore } from '../store/editorStore';

export const Inspector: React.FC = () => {
  const {
    selectedClipId,
    clips,
    updateClip,
    deleteClip,
    duplicateClip,
    splitClip,
    playhead,
  } = useEditorStore();

  const clip = clips.find((c) => c.id === selectedClipId);

  if (!clip) {
    return (
      <aside className="w-80 bg-[#0e0f14] border-l border-[#232633] flex flex-col h-full shrink-0 p-4 text-center justify-center items-center select-none">
        <Sliders className="w-10 h-10 text-slate-600 mb-3 opacity-40" />
        <h3 className="text-xs font-semibold text-slate-300">No Clip Selected</h3>
        <p className="text-[11px] text-slate-500 mt-1 max-w-[200px]">
          Select any clip on the timeline to edit its transformation, filters, volume, and timing.
        </p>
      </aside>
    );
  }

  const handleTransformChange = (key: keyof typeof clip.transform, value: number) => {
    updateClip(clip.id, {
      transform: {
        ...clip.transform,
        [key]: value,
      },
    });
  };

  const handleFilterChange = (key: keyof typeof clip.filters, value: number) => {
    updateClip(clip.id, {
      filters: {
        ...clip.filters,
        [key]: value,
      },
    });
  };

  const handleTextChange = (key: string, value: any) => {
    if (!clip.textConfig) return;
    updateClip(clip.id, {
      textConfig: {
        ...clip.textConfig,
        [key]: value,
      },
    });
  };

  const handleResetTransform = () => {
    updateClip(clip.id, {
      transform: { x: 0, y: 0, scale: 1, rotation: 0, opacity: 1 },
      filters: { brightness: 100, contrast: 100, saturation: 100, blur: 0, sepia: 0, grayscale: 0 },
    });
  };

  return (
    <aside className="w-80 bg-[#0e0f14] border-l border-[#232633] flex flex-col h-full shrink-0 select-none overflow-y-auto">
      {/* Inspector Header */}
      <div className="h-11 border-b border-[#232633] px-3.5 flex items-center justify-between bg-[#0c0d12] shrink-0">
        <div className="flex items-center space-x-2 truncate">
          <span
            className="w-2.5 h-2.5 rounded-full shrink-0"
            style={{ backgroundColor: clip.color || '#3b82f6' }}
          />
          <h2 className="text-xs font-bold text-white truncate">{clip.name}</h2>
        </div>

        {/* Quick Clip Operations */}
        <div className="flex items-center space-x-1 shrink-0">
          <button
            onClick={() => splitClip(clip.id, playhead)}
            title="Split Clip at Playhead (S)"
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-[#1f2230] transition-colors"
          >
            <Scissors className="w-3.5 h-3.5 text-indigo-400" />
          </button>
          <button
            onClick={() => duplicateClip(clip.id)}
            title="Duplicate Clip (Ctrl+D)"
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-[#1f2230] transition-colors"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => deleteClip(clip.id)}
            title="Delete Clip (Delete)"
            className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-[#1f2230] transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="p-3.5 space-y-4">
        {/* Clip Timing & Playback Speed */}
        <div className="bg-[#14151f] border border-[#232633] rounded-lg p-3 space-y-2.5">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
            <span className="flex items-center space-x-1.5">
              <Gauge className="w-3.5 h-3.5 text-indigo-400" />
              <span>Timing & Speed</span>
            </span>
            <span className="font-mono text-emerald-400">{clip.duration.toFixed(2)}s</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Start Time</label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={Number(clip.startTime.toFixed(2))}
                onChange={(e) => updateClip(clip.id, { startTime: Math.max(0, Number(e.target.value)) })}
                className="w-full bg-[#0d0e14] border border-[#292c3d] rounded px-2 py-1 text-slate-200 font-mono text-xs focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Speed Multiplier</label>
              <select
                value={clip.speed}
                onChange={(e) => {
                  const newSpeed = Number(e.target.value);
                  const newDuration = (clip.trimOut - clip.trimIn) / newSpeed;
                  updateClip(clip.id, { speed: newSpeed, duration: newDuration });
                }}
                className="w-full bg-[#0d0e14] border border-[#292c3d] rounded px-2 py-1 text-slate-200 font-mono text-xs focus:outline-none focus:border-indigo-500"
              >
                <option value="0.25">0.25x (Slow)</option>
                <option value="0.5">0.5x</option>
                <option value="1">1.0x (Normal)</option>
                <option value="1.5">1.5x</option>
                <option value="2">2.0x (Fast)</option>
                <option value="4">4.0x (Hyper)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Text Settings (If text clip) */}
        {clip.type === 'text' && clip.textConfig && (
          <div className="bg-[#14151f] border border-[#232633] rounded-lg p-3 space-y-3">
            <div className="flex items-center space-x-1.5 text-[11px] font-semibold text-amber-400">
              <Type className="w-3.5 h-3.5" />
              <span>Text & Typography</span>
            </div>

            <div>
              <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Title Content</label>
              <textarea
                rows={2}
                value={clip.textConfig.text}
                onChange={(e) => handleTextChange('text', e.target.value)}
                className="w-full bg-[#0d0e14] border border-[#292c3d] rounded p-2 text-xs text-white focus:outline-none focus:border-amber-500 resize-none font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Font Size (px)</label>
                <input
                  type="number"
                  min="16"
                  max="120"
                  value={clip.textConfig.fontSize}
                  onChange={(e) => handleTextChange('fontSize', Number(e.target.value))}
                  className="w-full bg-[#0d0e14] border border-[#292c3d] rounded px-2 py-1 text-xs font-mono text-slate-200"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Font Weight</label>
                <select
                  value={clip.textConfig.fontWeight}
                  onChange={(e) => handleTextChange('fontWeight', e.target.value)}
                  className="w-full bg-[#0d0e14] border border-[#292c3d] rounded px-2 py-1 text-xs text-slate-200"
                >
                  <option value="normal">Regular</option>
                  <option value="500">Medium</option>
                  <option value="bold">Bold</option>
                  <option value="900">Black</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Text Color</label>
                <input
                  type="color"
                  value={clip.textConfig.color}
                  onChange={(e) => handleTextChange('color', e.target.value)}
                  className="w-full h-8 bg-[#0d0e14] border border-[#292c3d] rounded cursor-pointer"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Box Backdrop</label>
                <select
                  value={clip.textConfig.backgroundColor || 'transparent'}
                  onChange={(e) => handleTextChange('backgroundColor', e.target.value)}
                  className="w-full bg-[#0d0e14] border border-[#292c3d] rounded px-2 py-1 text-xs text-slate-200 h-8"
                >
                  <option value="transparent">None</option>
                  <option value="rgba(0, 0, 0, 0.6)">Black 60%</option>
                  <option value="rgba(15, 23, 42, 0.85)">Slate Navy</option>
                  <option value="rgba(79, 70, 229, 0.7)">Indigo Tint</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Transform Panel (Position, Scale, Rotation, Opacity) */}
        {clip.type !== 'audio' && (
          <div className="bg-[#14151f] border border-[#232633] rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
              <span className="flex items-center space-x-1.5">
                <Move className="w-3.5 h-3.5 text-indigo-400" />
                <span>Transform & Framing</span>
              </span>
              <button
                onClick={handleResetTransform}
                title="Reset Transform"
                className="text-[10px] text-slate-500 hover:text-slate-300 flex items-center space-x-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            </div>

            {/* Scale Slider */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Scale</span>
                <span className="font-mono text-slate-200">{Math.round(clip.transform.scale * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="3.0"
                step="0.05"
                value={clip.transform.scale}
                onChange={(e) => handleTransformChange('scale', Number(e.target.value))}
                className="w-full cursor-pointer h-1.5 bg-[#252838] rounded-lg"
              />
            </div>

            {/* Position X and Y */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Position X (%)</label>
                <input
                  type="number"
                  min="-100"
                  max="100"
                  value={Math.round(clip.transform.x)}
                  onChange={(e) => handleTransformChange('x', Number(e.target.value))}
                  className="w-full bg-[#0d0e14] border border-[#292c3d] rounded px-2 py-1 text-slate-200 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Position Y (%)</label>
                <input
                  type="number"
                  min="-100"
                  max="100"
                  value={Math.round(clip.transform.y)}
                  onChange={(e) => handleTransformChange('y', Number(e.target.value))}
                  className="w-full bg-[#0d0e14] border border-[#292c3d] rounded px-2 py-1 text-slate-200 font-mono text-xs"
                />
              </div>
            </div>

            {/* Rotation Slider */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Rotation</span>
                <span className="font-mono text-slate-200">{Math.round(clip.transform.rotation)}°</span>
              </div>
              <input
                type="range"
                min="-180"
                max="180"
                value={clip.transform.rotation}
                onChange={(e) => handleTransformChange('rotation', Number(e.target.value))}
                className="w-full cursor-pointer h-1.5 bg-[#252838] rounded-lg"
              />
            </div>

            {/* Opacity Slider */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Opacity</span>
                <span className="font-mono text-slate-200">{Math.round(clip.transform.opacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.02"
                value={clip.transform.opacity}
                onChange={(e) => handleTransformChange('opacity', Number(e.target.value))}
                className="w-full cursor-pointer h-1.5 bg-[#252838] rounded-lg"
              />
            </div>
          </div>
        )}

        {/* Audio Volume (Video or Audio clips) */}
        {(clip.type === 'audio' || clip.type === 'video') && (
          <div className="bg-[#14151f] border border-[#232633] rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
              <span className="flex items-center space-x-1.5">
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Audio Levels</span>
              </span>
              <span className="font-mono text-emerald-400">{Math.round(clip.volume * 100)}%</span>
            </div>

            <input
              type="range"
              min="0"
              max="2.0"
              step="0.05"
              value={clip.volume}
              onChange={(e) => updateClip(clip.id, { volume: Number(e.target.value) })}
              className="w-full cursor-pointer h-1.5 bg-[#252838] rounded-lg"
            />
          </div>
        )}

        {/* Visual Color Grading / Filters (Video or Image clips) */}
        {(clip.type === 'video' || clip.type === 'image') && (
          <div className="bg-[#14151f] border border-[#232633] rounded-lg p-3 space-y-3">
            <div className="flex items-center space-x-1.5 text-[11px] font-semibold text-slate-300">
              <Sparkles className="w-3.5 h-3.5 text-violet-400" />
              <span>Color Grading & Looks</span>
            </div>

            {/* Quick preset buttons */}
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { name: 'Normal', f: { brightness: 100, contrast: 100, saturation: 100, sepia: 0, grayscale: 0 } },
                { name: 'Moody', f: { brightness: 95, contrast: 125, saturation: 90, sepia: 10, grayscale: 0 } },
                { name: 'Vibrant', f: { brightness: 105, contrast: 110, saturation: 140, sepia: 0, grayscale: 0 } },
                { name: 'B&W Film', f: { brightness: 105, contrast: 130, saturation: 0, sepia: 0, grayscale: 100 } },
                { name: 'Retro 80s', f: { brightness: 100, contrast: 115, saturation: 120, sepia: 35, grayscale: 0 } },
                { name: 'Cyberpunk', f: { brightness: 110, contrast: 135, saturation: 150, sepia: 0, grayscale: 0 } },
              ].map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => updateClip(clip.id, { filters: { ...clip.filters, ...p.f } })}
                  className="bg-[#1a1c27] hover:bg-[#232637] border border-[#282b3d] text-[10px] text-slate-300 font-medium py-1 rounded transition-colors"
                >
                  {p.name}
                </button>
              ))}
            </div>

            {/* Brightness */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Brightness</span>
                <span className="font-mono text-slate-200">{clip.filters.brightness}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="150"
                value={clip.filters.brightness}
                onChange={(e) => handleFilterChange('brightness', Number(e.target.value))}
                className="w-full cursor-pointer h-1.5 bg-[#252838] rounded-lg"
              />
            </div>

            {/* Contrast */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Contrast</span>
                <span className="font-mono text-slate-200">{clip.filters.contrast}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="150"
                value={clip.filters.contrast}
                onChange={(e) => handleFilterChange('contrast', Number(e.target.value))}
                className="w-full cursor-pointer h-1.5 bg-[#252838] rounded-lg"
              />
            </div>

            {/* Saturation */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Saturation</span>
                <span className="font-mono text-slate-200">{clip.filters.saturation}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="200"
                value={clip.filters.saturation}
                onChange={(e) => handleFilterChange('saturation', Number(e.target.value))}
                className="w-full cursor-pointer h-1.5 bg-[#252838] rounded-lg"
              />
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
