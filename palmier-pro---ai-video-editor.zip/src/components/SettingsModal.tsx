import React from 'react';
import { Settings, X, Sliders, Clock, Film } from 'lucide-react';
import { useEditorStore } from '../store/editorStore';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { projectSettings, updateProjectSettings } = useEditorStore();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#10121a] border border-[#252839] rounded-xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="h-14 border-b border-[#232637] px-5 flex items-center justify-between bg-[#131522]">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Project Settings</h2>
              <p className="text-[11px] text-slate-400">Master workspace configuration</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-[#1f2233] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs">
          {/* Project Name */}
          <div>
            <label className="text-slate-400 font-medium block mb-1">Project Name</label>
            <input
              type="text"
              value={projectSettings.name}
              onChange={(e) => updateProjectSettings({ name: e.target.value })}
              className="w-full bg-[#151724] border border-[#26283b] rounded-lg px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Project Timeline Duration */}
          <div>
            <label className="text-slate-400 font-medium block mb-1">
              Timeline Duration (Seconds)
            </label>
            <input
              type="number"
              min="5"
              max="600"
              value={projectSettings.duration}
              onChange={(e) => updateProjectSettings({ duration: Math.max(5, Number(e.target.value)) })}
              className="w-full bg-[#151724] border border-[#26283b] rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Master FPS */}
          <div>
            <label className="text-slate-400 font-medium block mb-1">Project Frame Rate</label>
            <div className="grid grid-cols-3 gap-2">
              {[24, 30, 60].map((rate) => (
                <button
                  key={rate}
                  onClick={() => updateProjectSettings({ fps: rate })}
                  className={`py-2 rounded-lg border font-mono font-medium transition-colors ${
                    projectSettings.fps === rate
                      ? 'bg-indigo-600 border-indigo-500 text-white'
                      : 'bg-[#151724] border-[#26283b] text-slate-400 hover:text-white'
                  }`}
                >
                  {rate} FPS
                </button>
              ))}
            </div>
          </div>

          {/* Snap Magnet Tolerance */}
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-400 font-medium">Magnet Snap Threshold</span>
              <span className="font-mono text-slate-200">
                {(projectSettings.snapTolerance * 1000).toFixed(0)} ms
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.5"
              step="0.01"
              value={projectSettings.snapTolerance}
              onChange={(e) => updateProjectSettings({ snapTolerance: Number(e.target.value) })}
              className="w-full cursor-pointer h-1.5 bg-[#252838] rounded-lg"
            />
          </div>

          {/* Background Canvas Color */}
          <div>
            <label className="text-slate-400 font-medium block mb-1">Canvas Background Matte</label>
            <div className="flex items-center space-x-2">
              <input
                type="color"
                value={projectSettings.backgroundColor}
                onChange={(e) => updateProjectSettings({ backgroundColor: e.target.value })}
                className="w-10 h-8 bg-transparent cursor-pointer rounded"
              />
              <span className="font-mono text-slate-300">{projectSettings.backgroundColor}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="h-14 border-t border-[#232637] px-5 flex items-center justify-end bg-[#131522]">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
