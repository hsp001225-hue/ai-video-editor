import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  X,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  RotateCcw,
  Check,
  Code2,
  Scissors,
  Type,
  Gauge,
  Volume2,
  Layers,
  Move,
  Trash2,
  Maximize2,
  Bookmark,
  Music,
  PlusCircle,
  HelpCircle,
  Undo2,
  Redo2,
  ChevronRight,
  Eye,
} from 'lucide-react';
import { useEditorStore } from '../store/editorStore';
import {
  EditingCommand,
  CommandValidationResult,
  ParsedCommandPlan,
  SupportedCommandType,
} from '../types/editor';
import { validateCommand } from '../lib/commandValidator';
import { executeCommandBatch, executeEditingCommand } from '../lib/commandExecutor';

interface AIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  plan?: {
    explanation: string;
    rawCommands: any[];
    validationResults: CommandValidationResult[];
  };
  status?: 'pending' | 'applied' | 'rejected' | 'error';
  executionMessages?: string[];
  executionErrors?: string[];
}

const QUICK_EXAMPLES = [
  'Move clip 2 to 15 seconds.',
  'Split clip 1 at 3 seconds.',
  'Change volume of audio to 40%.',
  'Add marker at 6 seconds with label "Drop Beat".',
  'Change speed of clip 2 to 1.5x.',
  'Add text title "CYBERPUNK NEON" at 2s.',
  'Add crossfade transition to clip 1.',
  'Change aspect ratio to 9:16 for TikTok.',
  'Undo last edit.',
];

export const AIAssistant: React.FC<AIAssistantProps> = ({ isOpen, onClose }) => {
  const {
    tracks,
    clips,
    markers,
    assets,
    playhead,
    projectSettings,
    selectedClipId,
    undo,
  } = useEditorStore();

  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showJsonView, setShowJsonView] = useState<Record<string, boolean>>({});

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'assistant',
      text: 'I am your Palmier Pro structured AI editing parser. I interpret your natural language requests into verified JSON editing operations (move, trim, split, resize, volume, speed, text, transitions, markers, aspect ratio). Every command is strictly validated before execution.',
    },
  ]);

  if (!isOpen) return null;

  const handleSend = async (promptToSend?: string) => {
    const prompt = (promptToSend || inputPrompt).trim();
    if (!prompt || isLoading) return;

    const userMsgId = `msg-user-${Date.now()}`;
    setMessages((prev) => [...prev, { id: userMsgId, sender: 'user', text: prompt }]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const timelineState = {
        playhead,
        projectDuration: projectSettings.duration,
        selectedClipId,
        tracks,
        clips,
        markers,
        assets,
      };

      const res = await fetch('/api/ai/parse-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, timelineState }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to parse editing command');
      }

      const rawCommands: any[] = data.commands || [];

      // Validate every command through the command validation layer
      const validationResults: CommandValidationResult[] = rawCommands.map((cmd) =>
        validateCommand(cmd, clips, tracks, assets, projectSettings)
      );

      const hasInvalid = validationResults.some((vr) => !vr.valid);

      const aiMsgId = `msg-ai-${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: aiMsgId,
          sender: 'assistant',
          text: data.explanation || 'Prepared editing operations:',
          plan: {
            explanation: data.explanation,
            rawCommands,
            validationResults,
          },
          status: hasInvalid ? 'error' : 'pending',
        },
      ]);
    } catch (err: any) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-ai-${Date.now()}`,
          sender: 'assistant',
          text: `Command parsing error: ${err.message || 'Please check your connection and try again.'}`,
          status: 'error',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyCommands = (msgId: string, validationResults: CommandValidationResult[]) => {
    // Only execute valid commands
    const validCommands = validationResults.filter((r) => r.valid).map((r) => r.command);

    if (validCommands.length === 0) {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === msgId
            ? { ...m, status: 'error', executionErrors: ['No valid commands to execute.'] }
            : m
        )
      );
      return;
    }

    const results = executeCommandBatch(validCommands);
    const hasFailures = results.some((r) => !r.success);
    const messagesList = results.map((r) => r.message);
    const errorsList = results.filter((r) => !r.success).map((r) => r.error || 'Failed to apply');

    setMessages((prev) =>
      prev.map((m) =>
        m.id === msgId
          ? {
              ...m,
              status: hasFailures ? 'error' : 'applied',
              executionMessages: messagesList,
              executionErrors: errorsList.length > 0 ? errorsList : undefined,
            }
          : m
      )
    );
  };

  const handleRevert = (msgId: string) => {
    undo();
    setMessages((prev) =>
      prev.map((m) => (m.id === msgId ? { ...m, status: 'rejected' } : m))
    );
  };

  const toggleJson = (id: string) => {
    setShowJsonView((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const renderCommandBadge = (type: SupportedCommandType) => {
    switch (type) {
      case 'move_clip':
        return <Move className="w-3.5 h-3.5 text-blue-400" />;
      case 'trim_clip':
      case 'resize_clip':
        return <Scissors className="w-3.5 h-3.5 text-indigo-400" />;
      case 'split_clip':
        return <Scissors className="w-3.5 h-3.5 text-rose-400" />;
      case 'remove_clip':
        return <Trash2 className="w-3.5 h-3.5 text-rose-400" />;
      case 'change_volume':
        return <Volume2 className="w-3.5 h-3.5 text-emerald-400" />;
      case 'change_speed':
        return <Gauge className="w-3.5 h-3.5 text-cyan-400" />;
      case 'add_text':
        return <Type className="w-3.5 h-3.5 text-amber-400" />;
      case 'add_transition':
        return <Sparkles className="w-3.5 h-3.5 text-violet-400" />;
      case 'add_marker':
        return <Bookmark className="w-3.5 h-3.5 text-rose-400" />;
      case 'add_audio':
        return <Music className="w-3.5 h-3.5 text-teal-400" />;
      case 'change_aspect_ratio':
        return <Maximize2 className="w-3.5 h-3.5 text-fuchsia-400" />;
      case 'undo':
        return <Undo2 className="w-3.5 h-3.5 text-slate-400" />;
      case 'redo':
        return <Redo2 className="w-3.5 h-3.5 text-slate-400" />;
      default:
        return <PlusCircle className="w-3.5 h-3.5 text-indigo-400" />;
    }
  };

  return (
    <div className="w-96 bg-[#0c0d14] border-l border-[#232633] flex flex-col h-full shrink-0 shadow-2xl z-30 select-none">
      {/* Header */}
      <div className="h-12 border-b border-[#232633] px-4 flex items-center justify-between bg-[#0f1018] shrink-0">
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-tr from-indigo-500 to-emerald-400 p-[1px] flex items-center justify-center">
            <div className="w-full h-full bg-[#0c0d14] rounded-[5px] flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </div>
          <div>
            <h3 className="text-xs font-bold text-white tracking-wide">PALMIER AI PARSER</h3>
            <p className="text-[10px] text-slate-400 font-mono">Structured JSON Command Engine</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1 rounded text-slate-400 hover:text-white hover:bg-[#1f212f] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[90%] rounded-xl px-3.5 py-2.5 text-xs leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-900/20'
                  : 'bg-[#151722] text-slate-200 border border-[#26283a]'
              }`}
            >
              <p className="whitespace-pre-wrap">{msg.text}</p>
            </div>

            {/* AI Modification Plan & Validated JSON Commands */}
            {msg.plan && (
              <div className="w-full mt-2 bg-[#12141e] border border-indigo-500/30 rounded-lg p-3 space-y-2.5">
                <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
                  <span className="flex items-center space-x-1.5">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>
                      Modifications ({msg.plan.validationResults.length} operation
                      {msg.plan.validationResults.length > 1 ? 's' : ''})
                    </span>
                  </span>

                  <button
                    onClick={() => toggleJson(msg.id)}
                    className="flex items-center space-x-1 text-[10px] text-indigo-400 hover:text-indigo-300 bg-[#171926] px-2 py-0.5 rounded border border-[#27293a]"
                  >
                    <Code2 className="w-3 h-3" />
                    <span>{showJsonView[msg.id] ? 'Hide JSON' : 'View JSON'}</span>
                  </button>
                </div>

                {/* JSON Viewer */}
                {showJsonView[msg.id] && (
                  <pre className="bg-[#090a0f] border border-[#202232] rounded p-2.5 text-[10px] font-mono text-emerald-400 overflow-x-auto max-h-48">
                    {JSON.stringify(msg.plan.rawCommands, null, 2)}
                  </pre>
                )}

                {/* Modification Preview Items */}
                <div className="space-y-1.5">
                  {msg.plan.validationResults.map((result, idx) => (
                    <div
                      key={idx}
                      className={`border rounded p-2 text-xs transition-colors ${
                        result.valid
                          ? 'bg-[#161824] border-[#242738]'
                          : 'bg-rose-950/20 border-rose-500/40 text-rose-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-1.5">
                          {renderCommandBadge(result.command.type)}
                          <span className="font-mono text-[11px] font-semibold text-white uppercase tracking-wider">
                            {result.command.type}
                          </span>
                        </div>

                        {result.valid ? (
                          <span className="flex items-center space-x-1 text-[10px] text-emerald-400 font-medium">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Validated</span>
                          </span>
                        ) : (
                          <span className="flex items-center space-x-1 text-[10px] text-rose-400 font-medium">
                            <AlertCircle className="w-3 h-3" />
                            <span>Invalid</span>
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-slate-300 mt-1 font-medium">
                        {result.previewDescription}
                      </p>

                      {/* Display Warnings */}
                      {result.warnings.length > 0 && (
                        <div className="mt-1 space-y-0.5">
                          {result.warnings.map((w, wIdx) => (
                            <div
                              key={wIdx}
                              className="text-[10px] text-amber-400 flex items-center space-x-1"
                            >
                              <AlertTriangle className="w-2.5 h-2.5 shrink-0" />
                              <span>{w}</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Display Errors */}
                      {result.errors.length > 0 && (
                        <div className="mt-1 space-y-0.5">
                          {result.errors.map((e, eIdx) => (
                            <div
                              key={eIdx}
                              className="text-[10px] text-rose-400 flex items-center space-x-1"
                            >
                              <AlertCircle className="w-2.5 h-2.5 shrink-0" />
                              <span>{e}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Execution feedback */}
                {msg.executionMessages && (
                  <div className="bg-[#10121a] border border-emerald-500/30 rounded p-2 text-[10px] text-emerald-400 space-y-0.5">
                    {msg.executionMessages.map((m, mIdx) => (
                      <div key={mIdx} className="flex items-center space-x-1">
                        <Check className="w-3 h-3 shrink-0" />
                        <span>{m}</span>
                      </div>
                    ))}
                  </div>
                )}

                {msg.executionErrors && (
                  <div className="bg-[#1a0f12] border border-rose-500/40 rounded p-2 text-[10px] text-rose-400 space-y-0.5">
                    {msg.executionErrors.map((err, eIdx) => (
                      <div key={eIdx} className="flex items-center space-x-1">
                        <AlertCircle className="w-3 h-3 shrink-0" />
                        <span>{err}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Execution Actions: Apply / Undo */}
                <div className="flex items-center space-x-2 pt-1">
                  {msg.status === 'applied' ? (
                    <button
                      onClick={() => handleRevert(msg.id)}
                      className="flex-1 py-1.5 px-3 bg-[#1d1f2d] hover:bg-[#25283b] text-slate-300 hover:text-white rounded text-xs font-medium border border-[#2e3146] flex items-center justify-center space-x-1.5 transition-colors"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Undo Applied Edits</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => handleApplyCommands(msg.id, msg.plan!.validationResults)}
                      disabled={msg.plan.validationResults.every((r) => !r.valid)}
                      className="flex-1 py-2 px-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 disabled:hover:from-emerald-600 text-white rounded text-xs font-semibold shadow-md shadow-emerald-900/30 flex items-center justify-center space-x-1.5 transition-all active:scale-[0.98]"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Apply Validated Operations</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center space-x-2 text-xs text-slate-400 bg-[#151722] border border-[#26283a] rounded-xl px-3 py-2 w-fit">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
            <span>Parsing command with Gemini & generating structured operations...</span>
          </div>
        )}
      </div>

      {/* Suggested Quick Commands */}
      <div className="px-4 py-2 border-t border-[#202230] bg-[#0e0f17]">
        <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold mb-1.5">
          Quick Editing Prompts
        </p>
        <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
          {QUICK_EXAMPLES.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(prompt)}
              className="text-[10px] bg-[#161824] hover:bg-[#1e2030] text-slate-300 hover:text-white border border-[#282a3d] rounded-full px-2.5 py-1 text-left transition-colors flex items-center space-x-1"
            >
              <span>{prompt}</span>
              <ChevronRight className="w-2.5 h-2.5 opacity-60" />
            </button>
          ))}
        </div>
      </div>

      {/* Input Field */}
      <div className="p-3 border-t border-[#232633] bg-[#0c0d14]">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="relative flex items-center"
        >
          <input
            type="text"
            placeholder="e.g. Move clip 2 to 15 seconds, change speed to 1.5x..."
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            disabled={isLoading}
            className="w-full bg-[#141622] border border-[#262838] focus:border-indigo-500 rounded-lg pl-3 pr-10 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-colors font-medium"
          />
          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="absolute right-1.5 p-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 disabled:hover:bg-indigo-600 text-white rounded-md transition-all shadow-sm"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
