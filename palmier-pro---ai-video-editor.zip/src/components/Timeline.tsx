import React, { useRef, useState, useEffect } from 'react';
import {
  Scissors,
  Trash2,
  Copy,
  ZoomIn,
  ZoomOut,
  Eye,
  EyeOff,
  Volume2,
  VolumeX,
  Lock,
  Unlock,
  Plus,
  Magnet,
  Bookmark,
  Sparkles,
  ChevronRight,
} from 'lucide-react';
import { useEditorStore } from '../store/editorStore';
import { TimelineClip, TimelineTrack, TimelineMarker } from '../types/editor';
import { formatTimecode } from '../lib/videoRenderer';

export const Timeline: React.FC = () => {
  const {
    tracks,
    clips,
    markers,
    playhead,
    setPlayhead,
    zoom,
    setZoom,
    selectedClipId,
    selectClip,
    splitClip,
    deleteClip,
    duplicateClip,
    moveClip,
    trimClip,
    updateTrack,
    addTrack,
    addMarker,
    deleteMarker,
    snappingEnabled,
    setSnappingEnabled,
    projectSettings,
  } = useEditorStore();

  const rulerRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Dragging states
  const [draggingPlayhead, setDraggingPlayhead] = useState(false);
  const [movingClip, setMovingClip] = useState<{
    clipId: string;
    startX: number;
    initialStartTime: number;
    trackId: string;
  } | null>(null);

  const [trimmingClip, setTrimmingClip] = useState<{
    clipId: string;
    type: 'start' | 'end';
    startX: number;
    initialTrimIn: number;
    initialTrimOut: number;
    initialStartTime: number;
    initialDuration: number;
  } | null>(null);

  // Time ruler tick markers
  const timelineWidth = Math.max(1200, projectSettings.duration * zoom);
  const majorTickInterval = zoom >= 60 ? 1 : zoom >= 30 ? 2 : 5; // seconds per major tick

  const tickMarks: { second: number; isMajor: boolean }[] = [];
  for (let s = 0; s <= projectSettings.duration; s += majorTickInterval) {
    tickMarks.push({ second: s, isMajor: true });
  }

  // Handle Playhead Scrubbing
  const handleRulerMouseDown = (e: React.MouseEvent) => {
    if (!rulerRef.current) return;
    const rect = rulerRef.current.getBoundingClientRect();
    const x = Math.max(0, e.clientX - rect.left);
    const newTime = Math.min(projectSettings.duration, Math.max(0, x / zoom));
    setPlayhead(newTime);
    setDraggingPlayhead(true);
  };

  // Handle Clip Move Drag
  const handleClipMouseDown = (e: React.MouseEvent, clip: TimelineClip) => {
    e.stopPropagation();
    selectClip(clip.id);

    const track = tracks.find((t) => t.id === clip.trackId);
    if (track?.locked) return;

    setMovingClip({
      clipId: clip.id,
      startX: e.clientX,
      initialStartTime: clip.startTime,
      trackId: clip.trackId,
    });
  };

  // Handle Clip Trim Drag (Start handle or End handle)
  const handleTrimMouseDown = (
    e: React.MouseEvent,
    clip: TimelineClip,
    type: 'start' | 'end'
  ) => {
    e.stopPropagation();
    selectClip(clip.id);

    const track = tracks.find((t) => t.id === clip.trackId);
    if (track?.locked) return;

    setTrimmingClip({
      clipId: clip.id,
      type,
      startX: e.clientX,
      initialTrimIn: clip.trimIn,
      initialTrimOut: clip.trimOut,
      initialStartTime: clip.startTime,
      initialDuration: clip.duration,
    });
  };

  // Global mouse move & mouse up listeners
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // 1. Scrubbing Playhead
      if (draggingPlayhead && rulerRef.current) {
        const rect = rulerRef.current.getBoundingClientRect();
        const x = Math.max(0, e.clientX - rect.left);
        const newTime = Math.min(projectSettings.duration, Math.max(0, x / zoom));
        setPlayhead(newTime);
      }

      // 2. Moving Clip
      if (movingClip) {
        const deltaPixels = e.clientX - movingClip.startX;
        const deltaTime = deltaPixels / zoom;
        const newStartTime = Math.max(0, movingClip.initialStartTime + deltaTime);
        moveClip(movingClip.clipId, newStartTime, movingClip.trackId);
      }

      // 3. Trimming Clip
      if (trimmingClip) {
        const deltaPixels = e.clientX - trimmingClip.startX;
        const deltaTime = deltaPixels / zoom;

        if (trimmingClip.type === 'start') {
          const newTrimIn = trimmingClip.initialTrimIn + deltaTime;
          const newStartTime = trimmingClip.initialStartTime + deltaTime;
          if (newTrimIn < trimmingClip.initialTrimOut - 0.2 && newStartTime >= 0) {
            trimClip(trimmingClip.clipId, newTrimIn, trimmingClip.initialTrimOut, newStartTime);
          }
        } else {
          const newTrimOut = trimmingClip.initialTrimOut + deltaTime;
          if (newTrimOut > trimmingClip.initialTrimIn + 0.2) {
            trimClip(trimmingClip.clipId, trimmingClip.initialTrimIn, newTrimOut);
          }
        }
      }
    };

    const handleMouseUp = () => {
      setDraggingPlayhead(false);
      setMovingClip(null);
      setTrimmingClip(null);
    };

    if (draggingPlayhead || movingClip || trimmingClip) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [
    draggingPlayhead,
    movingClip,
    trimmingClip,
    zoom,
    projectSettings.duration,
    setPlayhead,
    moveClip,
    trimClip,
  ]);

  return (
    <div className="h-64 bg-[#0a0b0f] border-t border-[#232633] flex flex-col shrink-0 select-none z-10">
      {/* Timeline Action Header Bar */}
      <div className="h-9 border-b border-[#232633] bg-[#0e0f16] px-3 flex items-center justify-between shrink-0">
        {/* Left: Timeline Editing Tools */}
        <div className="flex items-center space-x-1">
          <button
            onClick={() => selectedClipId && splitClip(selectedClipId, playhead)}
            disabled={!selectedClipId}
            title="Split Clip at Playhead (S)"
            className="flex items-center space-x-1 px-2 py-1 rounded bg-[#161823] hover:bg-[#202333] text-slate-300 hover:text-white border border-[#282a3c] disabled:opacity-30 disabled:pointer-events-none transition-colors text-xs font-medium"
          >
            <Scissors className="w-3.5 h-3.5 text-indigo-400" />
            <span>Split</span>
          </button>

          <button
            onClick={() => selectedClipId && duplicateClip(selectedClipId)}
            disabled={!selectedClipId}
            title="Duplicate Clip (Ctrl+D)"
            className="flex items-center space-x-1 px-2 py-1 rounded bg-[#161823] hover:bg-[#202333] text-slate-300 hover:text-white border border-[#282a3c] disabled:opacity-30 disabled:pointer-events-none transition-colors text-xs font-medium"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Duplicate</span>
          </button>

          <button
            onClick={() => selectedClipId && deleteClip(selectedClipId)}
            disabled={!selectedClipId}
            title="Delete Selected Clip (Delete)"
            className="flex items-center space-x-1 px-2 py-1 rounded bg-[#161823] hover:bg-[#202333] text-slate-300 hover:text-rose-400 border border-[#282a3c] disabled:opacity-30 disabled:pointer-events-none transition-colors text-xs font-medium"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>

          <div className="h-4 w-[1px] bg-[#232633] mx-1" />

          {/* Add Marker */}
          <button
            onClick={() => addMarker(playhead, `Marker @ ${playhead.toFixed(1)}s`)}
            title="Drop marker at current playhead"
            className="flex items-center space-x-1 px-2 py-1 rounded bg-[#161823] hover:bg-[#202333] text-slate-300 hover:text-amber-400 border border-[#282a3c] transition-colors text-xs font-medium"
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-400" />
            <span>+ Marker</span>
          </button>

          <div className="h-4 w-[1px] bg-[#232633] mx-1" />

          {/* Add Track */}
          <button
            onClick={() => addTrack('video')}
            className="flex items-center space-x-1 px-2 py-1 rounded text-slate-400 hover:text-slate-200 hover:bg-[#181a25] transition-colors text-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Video</span>
          </button>
          <button
            onClick={() => addTrack('audio')}
            className="flex items-center space-x-1 px-2 py-1 rounded text-slate-400 hover:text-slate-200 hover:bg-[#181a25] transition-colors text-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Audio</span>
          </button>
        </div>

        {/* Right: Snapping & Zoom Controls */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setSnappingEnabled(!snappingEnabled)}
            className={`p-1 rounded text-xs flex items-center space-x-1 transition-colors ${
              snappingEnabled ? 'text-indigo-400 bg-indigo-950/40' : 'text-slate-500 hover:text-slate-300'
            }`}
            title={`Magnet Snapping: ${snappingEnabled ? 'Active' : 'Off'}`}
          >
            <Magnet className="w-3.5 h-3.5" />
            <span className="text-[10px] uppercase font-semibold">Snap</span>
          </button>

          <div className="flex items-center space-x-1 bg-[#141520] border border-[#232633] rounded px-1.5 py-0.5">
            <button
              onClick={() => setZoom(zoom - 10)}
              title="Zoom Out (-)"
              className="p-1 rounded text-slate-400 hover:text-white"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>

            <input
              type="range"
              min="15"
              max="120"
              value={zoom}
              onChange={(e) => setZoom(Number(e.target.value))}
              className="w-16 h-1 cursor-pointer"
            />

            <button
              onClick={() => setZoom(zoom + 10)}
              title="Zoom In (+)"
              className="p-1 rounded text-slate-400 hover:text-white"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Track & Timeline Grid View */}
      <div className="flex-1 flex overflow-hidden">
        {/* Track Headers (Left Column) */}
        <div className="w-48 bg-[#0b0c12] border-r border-[#232633] flex flex-col shrink-0 overflow-y-hidden">
          {/* Ruler Corner Spacer */}
          <div className="h-6 border-b border-[#232633] bg-[#090a0e] px-2 flex items-center justify-between text-[10px] text-slate-500 font-semibold tracking-wider uppercase">
            <span>Tracks ({tracks.length})</span>
            <span className="text-[9px] text-slate-600 font-mono">ID</span>
          </div>

          {/* Track Header Items */}
          <div className="flex-1 overflow-y-auto space-y-[2px] py-[1px]">
            {tracks.map((track) => (
              <div
                key={track.id}
                className="h-12 bg-[#12131b] border-b border-[#1c1e2a] px-2 flex items-center justify-between group"
              >
                <div className="flex items-center space-x-1.5 truncate">
                  <span
                    className={`w-1.5 h-4 rounded-full ${
                      track.type === 'video'
                        ? 'bg-blue-500'
                        : track.type === 'audio'
                        ? 'bg-emerald-500'
                        : 'bg-amber-500'
                    }`}
                  />
                  <div className="truncate">
                    <p className="text-[11px] font-medium text-slate-300 truncate leading-tight">
                      {track.name}
                    </p>
                    <p className="text-[9px] font-mono text-slate-600 truncate">{track.id}</p>
                  </div>
                </div>

                {/* Track Controls */}
                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => updateTrack(track.id, { hidden: !track.hidden })}
                    title={track.hidden ? 'Show Track' : 'Hide Track'}
                    className={`p-1 rounded text-slate-400 hover:text-white ${
                      track.hidden ? 'text-amber-500' : ''
                    }`}
                  >
                    {track.hidden ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  </button>

                  <button
                    onClick={() => updateTrack(track.id, { muted: !track.muted })}
                    title={track.muted ? 'Unmute Track' : 'Mute Track'}
                    className={`p-1 rounded text-slate-400 hover:text-white ${
                      track.muted ? 'text-rose-500' : ''
                    }`}
                  >
                    {track.muted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                  </button>

                  <button
                    onClick={() => updateTrack(track.id, { locked: !track.locked })}
                    title={track.locked ? 'Unlock Track' : 'Lock Track'}
                    className={`p-1 rounded text-slate-400 hover:text-white ${
                      track.locked ? 'text-amber-400' : ''
                    }`}
                  >
                    {track.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Scrollable Timeline Area (Ruler + Tracks Canvas) */}
        <div
          ref={scrollContainerRef}
          className="flex-1 overflow-x-auto overflow-y-hidden relative bg-[#07080b] flex flex-col"
          onClick={() => selectClip(null)}
        >
          {/* Time Ruler */}
          <div
            ref={rulerRef}
            onMouseDown={handleRulerMouseDown}
            style={{ width: `${timelineWidth}px` }}
            className="h-6 bg-[#0c0d14] border-b border-[#232633] relative cursor-pointer select-none shrink-0"
          >
            {/* Markers on Ruler */}
            {markers.map((marker) => (
              <div
                key={marker.id}
                onClick={(e) => {
                  e.stopPropagation();
                  setPlayhead(marker.time);
                }}
                style={{ left: `${marker.time * zoom}px` }}
                className="absolute top-0 bottom-0 z-20 group -ml-1.5 flex flex-col items-center cursor-pointer"
                title={`${marker.label} (${marker.time.toFixed(2)}s) - Click to seek`}
              >
                <div
                  className="w-3 h-3 rotate-45 rounded-[1px] border border-white shadow-md shadow-black"
                  style={{ backgroundColor: marker.color }}
                />
                <span className="hidden group-hover:block absolute top-4 bg-black/90 text-white text-[9px] px-1.5 py-0.5 rounded border border-slate-700 whitespace-nowrap z-50">
                  {marker.label}
                </span>
              </div>
            ))}

            {/* Ruler Ticks */}
            {tickMarks.map((tick) => (
              <div
                key={tick.second}
                style={{ left: `${tick.second * zoom}px` }}
                className="absolute top-0 bottom-0 border-l border-[#242738] flex flex-col justify-end pb-0.5 pl-1"
              >
                <span className="font-mono text-[9px] text-slate-400 font-medium">
                  {formatTimecode(tick.second, projectSettings.fps).slice(3, 8)}
                </span>
              </div>
            ))}
          </div>

          {/* Tracks Lane Content */}
          <div
            style={{ width: `${timelineWidth}px` }}
            className="flex-1 relative space-y-[2px] py-[1px] timeline-grid"
          >
            {tracks.map((track) => (
              <div
                key={track.id}
                className="h-12 bg-[#0e1017]/50 border-b border-[#1b1d28] relative"
              >
                {/* Clips in this track */}
                {clips
                  .filter((c) => c.trackId === track.id)
                  .map((clip) => {
                    const isSelected = selectedClipId === clip.id;
                    const clipWidth = clip.duration * zoom;
                    const clipLeft = clip.startTime * zoom;
                    const clipGlobalIndex = clips.findIndex((c) => c.id === clip.id) + 1;

                    return (
                      <div
                        key={clip.id}
                        onMouseDown={(e) => handleClipMouseDown(e, clip)}
                        style={{
                          left: `${clipLeft}px`,
                          width: `${clipWidth}px`,
                          backgroundColor: clip.color || '#3b82f6',
                        }}
                        className={`absolute top-1 bottom-1 rounded-md cursor-grab active:cursor-grabbing flex items-center justify-between px-2 overflow-hidden shadow-md transition-shadow group ${
                          isSelected
                            ? 'ring-2 ring-white ring-offset-1 ring-offset-black z-20 brightness-110'
                            : 'hover:brightness-105 z-10'
                        }`}
                      >
                        {/* Left Trim Handle */}
                        <div
                          onMouseDown={(e) => handleTrimMouseDown(e, clip, 'start')}
                          title="Drag to trim start"
                          className="absolute left-0 top-0 bottom-0 w-2.5 bg-black/30 hover:bg-white/80 cursor-ew-resize opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center z-10"
                        >
                          <div className="w-0.5 h-4 bg-white/70 rounded-full" />
                        </div>

                        {/* Transition overlay visual indicator */}
                        {clip.transition && (
                          <div className="absolute inset-y-0 left-0 w-6 bg-gradient-to-r from-violet-500/40 to-transparent pointer-events-none flex items-center pl-0.5">
                            <Sparkles className="w-2.5 h-2.5 text-violet-300" />
                          </div>
                        )}

                        {/* Clip Content Label with Index Badge */}
                        <div className="truncate text-[11px] font-semibold text-white drop-shadow-sm pointer-events-none flex items-center space-x-1.5 pl-1 pr-2">
                          <span className="bg-black/40 px-1 py-0.2 rounded text-[9px] font-mono text-slate-200">
                            #{clipGlobalIndex}
                          </span>
                          <span className="truncate">{clip.name}</span>
                          <span className="text-[9px] opacity-80 font-mono">
                            {clip.duration.toFixed(1)}s
                          </span>
                          {clip.transition && (
                            <span className="bg-violet-950/70 border border-violet-500/40 text-violet-300 text-[8px] uppercase px-1 rounded">
                              {clip.transition.type}
                            </span>
                          )}
                        </div>

                        {/* Right Trim Handle */}
                        <div
                          onMouseDown={(e) => handleTrimMouseDown(e, clip, 'end')}
                          title="Drag to trim end"
                          className="absolute right-0 top-0 bottom-0 w-2.5 bg-black/30 hover:bg-white/80 cursor-ew-resize opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center z-10"
                        >
                          <div className="w-0.5 h-4 bg-white/70 rounded-full" />
                        </div>
                      </div>
                    );
                  })}
              </div>
            ))}

            {/* Playhead Needle line */}
            <div
              style={{ left: `${playhead * zoom}px` }}
              className="absolute top-0 bottom-0 pointer-events-none z-30 flex flex-col items-center"
            >
              {/* Playhead marker indicator head */}
              <div className="w-3.5 h-3.5 bg-rose-500 rotate-45 -mt-1.5 shadow-lg shadow-rose-500/50 border border-white" />
              <div className="w-[1.5px] h-full bg-rose-500 shadow-sm shadow-rose-500" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
