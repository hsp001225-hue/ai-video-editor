import React, { useState, useRef } from 'react';
import {
  Upload,
  Film,
  Music,
  Image as ImageIcon,
  Type,
  Search,
  Plus,
  Play,
  Trash2,
  FolderOpen,
  Sparkles,
  Loader2,
  CheckCircle2,
  Cpu,
} from 'lucide-react';
import { useEditorStore } from '../store/editorStore';
import { MediaAsset, MediaType } from '../types/editor';

type TabType = 'media' | 'stock' | 'audio' | 'titles';

export const MediaPanel: React.FC = () => {
  const { assets, addAsset, deleteAsset, addClip, tracks, playhead, projectSettings } = useEditorStore();
  const [activeTab, setActiveTab] = useState<TabType>('media');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<MediaType | 'all'>('all');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setUploadStatus(`FFmpeg probing: ${file.name}...`);

      try {
        const formData = new FormData();
        formData.append('media', file);

        const res = await fetch('/api/ffmpeg/upload', {
          method: 'POST',
          body: formData,
        });

        if (res.ok) {
          const data = await res.json();
          if (data.success && data.asset) {
            addAsset(data.asset);
            continue;
          }
        }
        throw new Error('Server probe failed, falling back to local metadata');
      } catch (err) {
        // Fallback to client-side metadata extraction
        const url = URL.createObjectURL(file);
        let type: MediaType = 'video';
        if (file.type.startsWith('audio/')) type = 'audio';
        else if (file.type.startsWith('image/')) type = 'image';

        if (type === 'video' || type === 'audio') {
          const media = document.createElement(type);
          media.src = url;
          await new Promise<void>((resolve) => {
            media.onloadedmetadata = () => {
              addAsset({
                id: `asset-up-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                name: file.name,
                type,
                url,
                duration: media.duration || 10,
                sizeBytes: file.size,
                blob: file,
              });
              resolve();
            };
            media.onerror = () => resolve();
          });
        } else {
          addAsset({
            id: `asset-up-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            name: file.name,
            type,
            url,
            duration: 5,
            sizeBytes: file.size,
            blob: file,
          });
        }
      }
    }

    setIsUploading(false);
    setUploadStatus(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAddToTimeline = (asset: MediaAsset) => {
    let track = tracks.find((t) => (asset.type === 'audio' ? t.type === 'audio' : t.type === 'video'));
    if (!track) track = tracks[0];

    addClip({
      trackId: track.id,
      assetId: asset.id,
      type: asset.type,
      name: asset.name,
      startTime: playhead,
      duration: Math.min(asset.duration, 8),
      trimIn: 0,
      trimOut: Math.min(asset.duration, 8),
      speed: 1.0,
      volume: asset.type === 'audio' ? 0.8 : 1.0,
      muted: false,
      transform: { x: 0, y: 0, scale: 1, rotation: 0, opacity: 1 },
      filters: { brightness: 100, contrast: 100, saturation: 100, blur: 0, sepia: 0, grayscale: 0 },
      color: asset.type === 'audio' ? '#10b981' : asset.type === 'image' ? '#8b5cf6' : '#3b82f6',
    });
  };

  const handleAddTitlePreset = (preset: { text: string; style: string; color: string }) => {
    let track = tracks.find((t) => t.type === 'overlay');
    if (!track) track = tracks[0];

    addClip({
      trackId: track.id,
      type: 'text',
      name: `Title: ${preset.text}`,
      startTime: playhead,
      duration: 4.5,
      trimIn: 0,
      trimOut: 4.5,
      speed: 1.0,
      volume: 1.0,
      muted: false,
      transform: { x: 0, y: 35, scale: 1, rotation: 0, opacity: 1 },
      filters: { brightness: 100, contrast: 100, saturation: 100, blur: 0, sepia: 0, grayscale: 0 },
      textConfig: {
        text: preset.text,
        fontSize: 48,
        fontFamily: 'Plus Jakarta Sans',
        fontWeight: 'bold',
        color: preset.color,
        backgroundColor: 'rgba(0, 0, 0, 0.55)',
        textAlign: 'center',
        shadow: true,
      },
      color: '#f59e0b',
    });
  };

  const filteredAssets = assets.filter((asset) => {
    const matchesSearch = asset.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterType === 'all' || asset.type === filterType;
    return matchesSearch && matchesFilter;
  });

  return (
    <aside className="w-72 bg-[#0e0f14] border-r border-[#232633] flex flex-col h-full shrink-0 z-10 select-none">
      {/* Tab Navigation */}
      <div className="flex border-b border-[#232633] bg-[#0c0d12]">
        <button
          onClick={() => setActiveTab('media')}
          className={`flex-1 py-2.5 text-[11px] font-semibold flex items-center justify-center space-x-1.5 transition-colors border-b-2 ${
            activeTab === 'media'
              ? 'text-white border-indigo-500 bg-[#14151e]'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          <FolderOpen className="w-3.5 h-3.5" />
          <span>Project</span>
        </button>
        <button
          onClick={() => setActiveTab('stock')}
          className={`flex-1 py-2.5 text-[11px] font-semibold flex items-center justify-center space-x-1.5 transition-colors border-b-2 ${
            activeTab === 'stock'
              ? 'text-white border-indigo-500 bg-[#14151e]'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          <Film className="w-3.5 h-3.5" />
          <span>Stock</span>
        </button>
        <button
          onClick={() => setActiveTab('audio')}
          className={`flex-1 py-2.5 text-[11px] font-semibold flex items-center justify-center space-x-1.5 transition-colors border-b-2 ${
            activeTab === 'audio'
              ? 'text-white border-indigo-500 bg-[#14151e]'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          <Music className="w-3.5 h-3.5" />
          <span>Audio</span>
        </button>
        <button
          onClick={() => setActiveTab('titles')}
          className={`flex-1 py-2.5 text-[11px] font-semibold flex items-center justify-center space-x-1.5 transition-colors border-b-2 ${
            activeTab === 'titles'
              ? 'text-white border-indigo-500 bg-[#14151e]'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          <Type className="w-3.5 h-3.5" />
          <span>Text</span>
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col p-3 overflow-hidden">
        {activeTab === 'media' || activeTab === 'stock' || activeTab === 'audio' ? (
          <>
            {/* Upload Button */}
            {activeTab === 'media' && (
              <div className="mb-3 space-y-1.5">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  multiple
                  accept="video/*,audio/*,image/*"
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="w-full flex items-center justify-center space-x-2 py-2 px-3 border border-dashed border-[#34374a] hover:border-indigo-500/60 bg-[#14161f] hover:bg-[#181a25] disabled:opacity-50 text-slate-300 hover:text-white rounded-lg text-xs font-medium transition-all group"
                >
                  {isUploading ? (
                    <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
                  ) : (
                    <Upload className="w-4 h-4 text-indigo-400 group-hover:scale-110 transition-transform" />
                  )}
                  <span>{isUploading ? 'Processing with FFmpeg...' : 'Import Media Files'}</span>
                </button>

                {uploadStatus && (
                  <p className="text-[10px] text-indigo-400 flex items-center space-x-1 font-mono">
                    <Cpu className="w-3 h-3 animate-pulse" />
                    <span>{uploadStatus}</span>
                  </p>
                )}
              </div>
            )}

            {/* Search & Filter Bar */}
            <div className="space-y-2 mb-3">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search assets..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#14161f] border border-[#232633] rounded-md pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>

              {/* Filter Pills */}
              <div className="flex items-center space-x-1">
                {(['all', 'video', 'audio', 'image'] as const).map((type) => (
                  <button
                    key={type}
                    onClick={() => setFilterType(type)}
                    className={`px-2 py-0.5 rounded text-[10px] uppercase font-semibold transition-colors ${
                      filterType === type
                        ? 'bg-indigo-600 text-white'
                        : 'bg-[#181a24] text-slate-400 hover:text-slate-200 hover:bg-[#202330]'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Asset Grid / List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {filteredAssets.length === 0 ? (
                <div className="h-40 flex flex-col items-center justify-center text-center p-4 text-slate-500">
                  <Film className="w-8 h-8 mb-2 opacity-40" />
                  <p className="text-xs">No media assets found</p>
                  <p className="text-[11px] text-slate-600 mt-1">Upload files or select a different filter</p>
                </div>
              ) : (
                filteredAssets.map((asset) => (
                  <div
                    key={asset.id}
                    className="group relative bg-[#141620] border border-[#222432] hover:border-indigo-500/50 rounded-lg p-2 flex items-center space-x-3 transition-all hover:bg-[#191b27]"
                  >
                    {/* Thumbnail */}
                    <div className="w-14 h-12 rounded bg-[#0a0b0e] overflow-hidden shrink-0 relative flex items-center justify-center border border-[#1f212c]">
                      {asset.thumbnail ? (
                        <img
                          src={asset.thumbnail}
                          alt={asset.name}
                          className="w-full h-full object-cover"
                        />
                      ) : asset.type === 'video' ? (
                        <Film className="w-5 h-5 text-indigo-400 opacity-70" />
                      ) : asset.type === 'audio' ? (
                        <Music className="w-5 h-5 text-emerald-400 opacity-70" />
                      ) : (
                        <ImageIcon className="w-5 h-5 text-violet-400 opacity-70" />
                      )}

                      <span className="absolute bottom-0.5 right-0.5 bg-black/80 px-1 rounded text-[9px] font-mono text-slate-300">
                        {Math.floor(asset.duration)}s
                      </span>
                    </div>

                    {/* Metadata */}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-slate-200 truncate group-hover:text-white">
                        {asset.name}
                      </p>
                      <div className="flex items-center space-x-2 mt-0.5">
                        <span className="text-[10px] uppercase font-semibold text-slate-500 tracking-wider">
                          {asset.type}
                        </span>
                        {asset.width && asset.height && (
                          <span className="text-[10px] text-slate-600 font-mono">
                            {asset.width}x{asset.height}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Quick Add Button */}
                    <button
                      onClick={() => handleAddToTimeline(asset)}
                      title="Add to timeline at playhead"
                      className="opacity-0 group-hover:opacity-100 p-1.5 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-sm shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </>
        ) : (
          /* Text / Titles Presets Tab */
          <div className="flex-1 overflow-y-auto space-y-2.5">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Preset Title Templates
            </div>

            {[
              { text: 'CINEMATIC OPENER', style: 'Bold Minimal', color: '#ffffff' },
              { text: 'LOWER THIRD // NAME', style: 'Sleek Subtitle', color: '#38bdf8' },
              { text: 'EPISODE 01: BEGINNING', style: 'Modern Neon', color: '#a855f7' },
              { text: 'WARNING: EXTREME', style: 'Cyberpunk Red', color: '#f43f5e' },
              { text: 'CHAPTER 02 // REVELATION', style: 'Gold Elegance', color: '#fbbf24' },
            ].map((preset, idx) => (
              <div
                key={idx}
                className="bg-[#141620] border border-[#222432] hover:border-amber-500/50 p-2.5 rounded-lg flex items-center justify-between group transition-colors"
              >
                <div>
                  <p className="text-xs font-bold text-white tracking-wide" style={{ color: preset.color }}>
                    {preset.text}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">{preset.style}</p>
                </div>

                <button
                  onClick={() => handleAddTitlePreset(preset)}
                  title="Add to timeline"
                  className="opacity-0 group-hover:opacity-100 p-1.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </aside>
  );
};
