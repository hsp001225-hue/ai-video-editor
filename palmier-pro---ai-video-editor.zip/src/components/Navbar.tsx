import React, { useState } from 'react';
import {
  Undo2,
  Redo2,
  Download,
  Settings,
  Magnet,
  CheckCircle2,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useEditorStore } from '../store/editorStore';
import { formatTimecode } from '../lib/videoRenderer';

interface NavbarProps {
  onOpenExport: () => void;
  onOpenSettings: () => void;
  onToggleAIAssistant: () => void;
  isAIAssistantOpen: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenExport,
  onOpenSettings,
  onToggleAIAssistant,
  isAIAssistantOpen,
}) => {
  const {
    projectSettings,
    updateProjectSettings,
    historyPast,
    historyFuture,
    undo,
    redo,
    playhead,
    snappingEnabled,
    setSnappingEnabled,
    lastSavedAt,
  } = useEditorStore();

  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState(projectSettings.name);

  const handleTitleSubmit = () => {
    setIsEditingTitle(false);
    if (titleInput.trim()) {
      updateProjectSettings({ name: titleInput.trim() });
    } else {
      setTitleInput(projectSettings.name);
    }
  };

  return (
    <header className="h-12 border-b border-[#232633] bg-[#0f1015] px-4 flex items-center justify-between z-20 shrink-0">
      {/* Left: Brand & Project Name */}
      <div className="flex items-center space-x-4">
        {/* Palmier Pro Logo */}
        <div className="flex items-center space-x-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-indigo-600 via-violet-600 to-emerald-400 p-[1px] flex items-center justify-center shadow-lg shadow-indigo-950/40">
            <div className="w-full h-full bg-[#0b0c10] rounded-[7px] flex items-center justify-center">
              <Layers className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="font-bold tracking-tight text-white text-sm">PALMIER</span>
            <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-400 border border-emerald-500/30">
              PRO
            </span>
          </div>
        </div>

        <div className="h-4 w-[1px] bg-[#232633]" />

        {/* Project Name & Save Status */}
        <div className="flex items-center space-x-2">
          {isEditingTitle ? (
            <input
              type="text"
              value={titleInput}
              onChange={(e) => setTitleInput(e.target.value)}
              onBlur={handleTitleSubmit}
              onKeyDown={(e) => e.key === 'Enter' && handleTitleSubmit()}
              autoFocus
              className="bg-[#171821] text-xs text-white border border-indigo-500 rounded px-2 py-1 outline-none w-48 font-medium"
            />
          ) : (
            <button
              onClick={() => setIsEditingTitle(true)}
              className="text-xs font-medium text-slate-200 hover:text-white px-2 py-1 rounded hover:bg-[#1a1b24] transition-colors truncate max-w-[200px]"
              title="Click to rename project"
            >
              {projectSettings.name}
            </button>
          )}

          <div className="flex items-center space-x-1 text-[11px] text-slate-400">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span className="hidden sm:inline">Saved</span>
          </div>
        </div>
      </div>

      {/* Middle: Undo / Redo & Timecode display */}
      <div className="flex items-center space-x-3">
        <div className="flex items-center bg-[#15161f] border border-[#232633] rounded-md p-0.5">
          <button
            onClick={undo}
            disabled={historyPast.length === 0}
            title="Undo (Ctrl+Z)"
            className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#232633] disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={redo}
            disabled={historyFuture.length === 0}
            title="Redo (Ctrl+Y)"
            className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-[#232633] disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Master Timecode */}
        <div className="flex items-center space-x-2 bg-[#12131b] border border-[#232633] px-2.5 py-1 rounded-md font-mono text-xs shadow-inner">
          <span className="text-emerald-400 font-semibold">{formatTimecode(playhead, projectSettings.fps)}</span>
          <span className="text-slate-600">/</span>
          <span className="text-slate-400">{formatTimecode(projectSettings.duration, projectSettings.fps)}</span>
        </div>

        {/* Snapping Magnet */}
        <button
          onClick={() => setSnappingEnabled(!snappingEnabled)}
          title={`Magnet Snapping: ${snappingEnabled ? 'Enabled' : 'Disabled'} (N)`}
          className={`p-1.5 rounded-md border text-xs flex items-center space-x-1 transition-colors ${
            snappingEnabled
              ? 'bg-indigo-950/50 border-indigo-500/40 text-indigo-400'
              : 'bg-[#15161f] border-[#232633] text-slate-400 hover:text-white'
          }`}
        >
          <Magnet className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Right: AI Assistant Toggle, Settings & Export */}
      <div className="flex items-center space-x-2.5">
        <button
          onClick={onToggleAIAssistant}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium border transition-all ${
            isAIAssistantOpen
              ? 'bg-gradient-to-r from-indigo-600/30 to-violet-600/30 border-indigo-500/60 text-indigo-300 shadow-sm shadow-indigo-500/10'
              : 'bg-[#171822] border-[#262838] text-slate-300 hover:text-white hover:border-[#383a4f]'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>AI Assistant</span>
        </button>

        <button
          onClick={onOpenSettings}
          title="Project Settings"
          className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-[#1f212c] transition-colors border border-transparent hover:border-[#2b2e3e]"
        >
          <Settings className="w-4 h-4" />
        </button>

        <button
          onClick={onOpenExport}
          className="flex items-center space-x-1.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-medium text-xs px-3.5 py-1.5 rounded-md shadow-md shadow-indigo-600/20 transition-all active:scale-[0.98]"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export</span>
        </button>
      </div>
    </header>
  );
};
