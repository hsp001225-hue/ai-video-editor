import React, { useState, useRef, useEffect } from 'react';
import {
  Download,
  X,
  CheckCircle2,
  Film,
  Sparkles,
  Sliders,
  Play,
  FileVideo,
  AlertCircle,
  Loader2,
  Cpu,
  Server,
  Monitor,
  RefreshCw,
} from 'lucide-react';
import { useEditorStore } from '../store/editorStore';
import { renderCompositionFrame } from '../lib/videoRenderer';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type ExportEngine = 'ffmpeg' | 'browser';

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const { projectSettings, tracks, clips, assets } = useEditorStore();

  const [engine, setEngine] = useState<ExportEngine>('ffmpeg');
  const [resolution, setResolution] = useState<'720p' | '1080p' | '4k'>('1080p');
  const [fps, setFps] = useState<24 | 30 | 60>(30);
  const [format, setFormat] = useState<'mp4' | 'webm'>('mp4');
  const [quality, setQuality] = useState<'draft' | 'standard' | 'high'>('high');

  // Asynchronous export state
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportStage, setExportStage] = useState('Preparing export');
  const [jobId, setJobId] = useState<string | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadFileName, setDownloadFileName] = useState('');
  const [exportError, setExportError] = useState<string | null>(null);

  const pollIntervalRef = useRef<any>(null);
  const cancelExportRef = useRef(false);

  // Clean up polling interval on unmount
  useEffect(() => {
    return () => {
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
      }
    };
  }, []);

  if (!isOpen) return null;

  // Calculate resolution dimensions based on aspect ratio
  const getExportDimensions = () => {
    const isPortrait = projectSettings.aspectRatio === '9:16';
    const isSquare = projectSettings.aspectRatio === '1:1';

    if (resolution === '720p') {
      if (isPortrait) return { width: 720, height: 1280 };
      if (isSquare) return { width: 720, height: 720 };
      return { width: 1280, height: 720 };
    } else if (resolution === '1080p') {
      if (isPortrait) return { width: 1080, height: 1920 };
      if (isSquare) return { width: 1080, height: 1080 };
      return { width: 1920, height: 1080 };
    } else {
      // 4K
      if (isPortrait) return { width: 2160, height: 3840 };
      if (isSquare) return { width: 2160, height: 2160 };
      return { width: 3840, height: 2160 };
    }
  };

  // 1. Real Server-side FFmpeg Asynchronous Render
  const handleStartFfmpegExport = async () => {
    setIsExporting(true);
    setExportProgress(5);
    setExportStage('Submitting export request to FFmpeg server...');
    setExportError(null);
    setDownloadUrl(null);

    const dims = getExportDimensions();

    try {
      const payload = {
        timeline: {
          duration: projectSettings.duration,
          width: dims.width,
          height: dims.height,
          fps,
          aspectRatio: projectSettings.aspectRatio,
          clips,
          tracks,
        },
      };

      const res = await fetch('/api/ffmpeg/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to initialize FFmpeg export job');
      }

      const activeJobId = data.jobId;
      setJobId(activeJobId);
      setExportStage('Job queued on FFmpeg background processor');

      // Poll status every 800ms
      pollIntervalRef.current = setInterval(async () => {
        try {
          const statusRes = await fetch(`/api/ffmpeg/export-status/${activeJobId}`);
          if (!statusRes.ok) return;

          const job = await statusRes.json();
          setExportProgress(job.progress || 10);
          setExportStage(job.stage || 'Processing timeline');

          if (job.status === 'completed') {
            clearInterval(pollIntervalRef.current);
            setIsExporting(false);
            setExportProgress(100);
            setDownloadUrl(job.downloadUrl);
            setDownloadFileName(job.outputFileName || 'palmier-master-export.mp4');
          } else if (job.status === 'failed') {
            clearInterval(pollIntervalRef.current);
            setIsExporting(false);
            setExportError(job.error || 'FFmpeg processing failed.');
          }
        } catch (err: any) {
          console.warn('Status poll warning:', err.message);
        }
      }, 800);
    } catch (err: any) {
      setIsExporting(false);
      setExportError(err.message || 'Could not start server-side FFmpeg export.');
    }
  };

  // 2. Client-side Canvas Fallback Export
  const handleStartBrowserExport = async () => {
    setIsExporting(true);
    setExportProgress(0);
    setExportStage('Rendering canvas frames in browser...');
    setDownloadUrl(null);
    cancelExportRef.current = false;

    const { width, height } = getExportDimensions();
    const renderCanvas = document.createElement('canvas');
    renderCanvas.width = width;
    renderCanvas.height = height;
    const ctx = renderCanvas.getContext('2d', { alpha: false });

    if (!ctx) {
      setIsExporting(false);
      setExportError('Could not allocate canvas rendering context.');
      return;
    }

    const duration = projectSettings.duration;
    const total = Math.floor(duration * fps);

    const stream = renderCanvas.captureStream(fps);
    const mimeType =
      format === 'mp4' && MediaRecorder.isTypeSupported('video/mp4;codecs=avc1')
        ? 'video/mp4;codecs=avc1'
        : MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';

    const bitrate =
      quality === 'high' ? 12_000_000 : quality === 'standard' ? 6_000_000 : 2_500_000;

    let mediaRecorder: MediaRecorder;
    try {
      mediaRecorder = new MediaRecorder(stream, {
        mimeType,
        videoBitsPerSecond: bitrate,
      });
    } catch {
      mediaRecorder = new MediaRecorder(stream);
    }

    const chunks: Blob[] = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: mimeType });
      const url = URL.createObjectURL(blob);
      const safeName = projectSettings.name.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const filename = `${safeName}-${resolution}-${fps}fps.${format === 'mp4' ? 'mp4' : 'webm'}`;
      setDownloadUrl(url);
      setDownloadFileName(filename);
      setIsExporting(false);
      setExportProgress(100);
      setExportStage('Completed');
    };

    mediaRecorder.start();

    const assetMap = new Map<string, { url: string; type: string; name: string }>();
    assets.forEach((a) => assetMap.set(a.id, { url: a.url, type: a.type, name: a.name }));

    let frame = 0;
    const renderFrame = () => {
      if (cancelExportRef.current) {
        mediaRecorder.stop();
        setIsExporting(false);
        return;
      }

      if (frame <= total) {
        const timeInSeconds = frame / fps;
        renderCompositionFrame(ctx, width, height, timeInSeconds, tracks, clips, assetMap);

        frame++;
        const pct = Math.min(99, Math.round((frame / total) * 100));
        setExportProgress(pct);
        setExportStage(`Encoding frame ${frame} of ${total} (${pct}%)`);

        setTimeout(renderFrame, 1000 / (fps * 2));
      } else {
        setTimeout(() => {
          mediaRecorder.stop();
        }, 300);
      }
    };

    renderFrame();
  };

  const handleStartExport = () => {
    if (engine === 'ffmpeg') {
      handleStartFfmpegExport();
    } else {
      handleStartBrowserExport();
    }
  };

  const handleCancelExport = () => {
    if (pollIntervalRef.current) {
      clearInterval(pollIntervalRef.current);
    }
    cancelExportRef.current = true;
    setIsExporting(false);
    setExportStage('Cancelled');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="bg-[#10121a] border border-[#252839] rounded-xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="h-14 border-b border-[#232637] px-5 flex items-center justify-between bg-[#131522]">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Export Video Project</h2>
              <p className="text-[11px] text-slate-400">Production FFmpeg & Canvas Engine</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-[#1f2233] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          {!isExporting && !downloadUrl && !exportError ? (
            <>
              {/* Engine Toggle: FFmpeg Server vs Browser */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Rendering Engine
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      setEngine('ffmpeg');
                      setFormat('mp4');
                    }}
                    className={`p-2.5 rounded-lg border text-left flex items-start space-x-2.5 transition-all ${
                      engine === 'ffmpeg'
                        ? 'bg-indigo-950/40 border-indigo-500/80 text-white shadow-sm'
                        : 'bg-[#151722] border-[#252839] text-slate-400 hover:text-white hover:bg-[#1b1e2c]'
                    }`}
                  >
                    <Server className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="text-xs font-semibold text-white flex items-center space-x-1">
                        <span>FFmpeg Server Engine</span>
                        <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1 py-0.2 rounded border border-emerald-500/30">
                          PRO
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Asynchronous H.264 encode. Timeline remains responsive.
                      </p>
                    </div>
                  </button>

                  <button
                    onClick={() => setEngine('browser')}
                    className={`p-2.5 rounded-lg border text-left flex items-start space-x-2.5 transition-all ${
                      engine === 'browser'
                        ? 'bg-indigo-950/40 border-indigo-500/80 text-white shadow-sm'
                        : 'bg-[#151722] border-[#252839] text-slate-400 hover:text-white hover:bg-[#1b1e2c]'
                    }`}
                  >
                    <Monitor className="w-4 h-4 text-indigo-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="text-xs font-semibold text-white">Browser Draft</div>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Fast in-browser canvas recorder for quick drafts.
                      </p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Resolution Choice */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Resolution Preset
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['720p', '1080p', '4k'] as const).map((res) => (
                    <button
                      key={res}
                      onClick={() => setResolution(res)}
                      className={`py-2 px-3 rounded-lg border text-xs font-semibold uppercase tracking-wider transition-all ${
                        resolution === res
                          ? 'bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-600/30'
                          : 'bg-[#151722] border-[#252839] text-slate-400 hover:text-white hover:bg-[#1b1e2c]'
                      }`}
                    >
                      {res} {res === '4k' && 'UHD'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Frame Rate & Container Format */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Frame Rate (FPS)
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {([24, 30, 60] as const).map((rate) => (
                      <button
                        key={rate}
                        onClick={() => setFps(rate)}
                        className={`py-1.5 rounded-md border text-xs font-mono font-medium transition-colors ${
                          fps === rate
                            ? 'bg-indigo-600 border-indigo-500 text-white'
                            : 'bg-[#151722] border-[#252839] text-slate-400 hover:text-white'
                        }`}
                      >
                        {rate}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Container Format
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(['mp4', 'webm'] as const).map((fmt) => (
                      <button
                        key={fmt}
                        onClick={() => setFormat(fmt)}
                        className={`py-1.5 rounded-md border text-xs font-mono uppercase font-medium transition-colors ${
                          format === fmt
                            ? 'bg-indigo-600 border-indigo-500 text-white'
                            : 'bg-[#151722] border-[#252839] text-slate-400 hover:text-white'
                        }`}
                      >
                        {fmt}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bitrate Quality */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Encoding Bitrate
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['draft', 'standard', 'high'] as const).map((q) => (
                    <button
                      key={q}
                      onClick={() => setQuality(q)}
                      className={`py-2 px-3 rounded-lg border text-xs capitalize font-medium transition-colors ${
                        quality === q
                          ? 'bg-indigo-600/30 border-indigo-500 text-indigo-300'
                          : 'bg-[#151722] border-[#252839] text-slate-400 hover:text-white'
                      }`}
                    >
                      {q} {q === 'high' ? '(12 Mbps)' : q === 'standard' ? '(6 Mbps)' : '(2.5 Mbps)'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Specs Summary */}
              <div className="bg-[#141623] border border-[#232638] rounded-lg p-3 text-xs text-slate-300 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Timeline Length:</span>
                  <span className="font-mono">{projectSettings.duration.toFixed(1)}s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Output Dimensions:</span>
                  <span className="font-mono">
                    {getExportDimensions().width} × {getExportDimensions().height} ({projectSettings.aspectRatio})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Audio Channels:</span>
                  <span className="font-mono text-emerald-400">Stereo 44.1kHz AAC</span>
                </div>
              </div>
            </>
          ) : isExporting ? (
            /* Active Asynchronous Export State */
            <div className="py-6 space-y-4 text-center">
              <div className="w-12 h-12 mx-auto rounded-full bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                <Cpu className="w-6 h-6 animate-pulse" />
              </div>

              <div>
                <h3 className="text-sm font-bold text-white">
                  {engine === 'ffmpeg' ? 'FFmpeg Server Encoding...' : 'Browser Canvas Rendering...'}
                </h3>
                <p className="text-xs text-indigo-400 mt-1 font-mono">{exportStage}</p>
                {jobId && (
                  <p className="text-[10px] text-slate-500 font-mono mt-0.5">Job: {jobId}</p>
                )}
              </div>

              {/* Progress bar */}
              <div className="w-full bg-[#181a28] h-3 rounded-full overflow-hidden border border-[#25283b]">
                <div
                  className="bg-gradient-to-r from-indigo-500 via-violet-500 to-emerald-400 h-full transition-all duration-300"
                  style={{ width: `${exportProgress}%` }}
                />
              </div>

              <div className="flex justify-between text-[11px] text-slate-400 px-1 font-mono">
                <span>Progress: {exportProgress}%</span>
                <span>Aspect: {projectSettings.aspectRatio}</span>
              </div>

              {/* Informative banner about background responsiveness */}
              <div className="bg-[#141624] border border-[#26283a] rounded-lg p-2.5 text-[11px] text-slate-300 text-left">
                <p className="text-emerald-400 font-semibold mb-0.5">⚡ Asynchronous Processing Active</p>
                <p className="text-slate-400">
                  The editing timeline remains fully interactive. You can close this modal and continue splitting, trimming, or editing clips while FFmpeg renders in the background.
                </p>
              </div>

              <button
                onClick={handleCancelExport}
                className="text-xs text-rose-400 hover:text-rose-300 hover:underline pt-2 block mx-auto"
              >
                Cancel Export
              </button>
            </div>
          ) : exportError ? (
            /* Error State */
            <div className="py-6 space-y-4 text-center">
              <div className="w-12 h-12 mx-auto rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                <AlertCircle className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-sm font-bold text-white">Export Processing Error</h3>
                <p className="text-xs text-rose-300 mt-1 max-w-sm mx-auto">{exportError}</p>
              </div>

              <div className="flex justify-center space-x-2 pt-2">
                <button
                  onClick={() => setExportError(null)}
                  className="px-4 py-2 bg-[#1b1d2c] hover:bg-[#23263a] text-slate-200 text-xs font-semibold rounded-lg border border-[#2d3047] flex items-center space-x-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Configure Settings</span>
                </button>
              </div>
            </div>
          ) : (
            /* Completed State */
            <div className="py-6 space-y-4 text-center">
              <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-sm font-bold text-white">Export Completed Successfully!</h3>
                <p className="text-xs text-slate-300 mt-1 font-mono">{downloadFileName}</p>
                <p className="text-[11px] text-emerald-400 mt-0.5">Master MP4 Encoded with H.264 & AAC</p>
              </div>

              <a
                href={downloadUrl!}
                download={downloadFileName}
                className="inline-flex items-center space-x-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-xs py-2.5 px-6 rounded-lg shadow-lg shadow-emerald-950 transition-transform active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>Download Master MP4</span>
              </a>

              <div>
                <button
                  onClick={() => {
                    setDownloadUrl(null);
                    setExportProgress(0);
                  }}
                  className="text-xs text-slate-500 hover:text-slate-300 underline"
                >
                  Export Another Version
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        {!isExporting && !downloadUrl && !exportError && (
          <div className="h-14 border-t border-[#232637] px-5 flex items-center justify-end space-x-2 bg-[#131522]">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-white hover:bg-[#1a1c2b] transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleStartExport}
              className="px-5 py-2 rounded-lg text-xs font-semibold bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-md shadow-indigo-600/30 flex items-center space-x-1.5 transition-transform active:scale-95"
            >
              <Film className="w-3.5 h-3.5" />
              <span>{engine === 'ffmpeg' ? 'Start FFmpeg Master Render' : 'Start Browser Render'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
