import React, { useEffect, useRef, useState, useMemo } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Repeat,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { useEditorStore } from '../store/editorStore';
import { renderCompositionFrame, formatTimecode, getCachedMediaElement } from '../lib/videoRenderer';
import { AspectRatioType } from '../types/editor';

export const PreviewPlayer: React.FC = () => {
  const {
    playhead,
    setPlayhead,
    isPlaying,
    setIsPlaying,
    togglePlay,
    projectSettings,
    updateProjectSettings,
    tracks,
    clips,
    assets,
    selectedClipId,
    updateClip,
  } = useEditorStore();

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLooping, setIsLooping] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [displayScale, setDisplayScale] = useState<'fit' | '100%' | '75%' | '50%'>('fit');

  // Asset Map for fast lookup
  const assetMap = useMemo(() => {
    const map = new Map<string, { url: string; type: string; name: string }>();
    assets.forEach((a) => map.set(a.id, { url: a.url, type: a.type, name: a.name }));
    return map;
  }, [assets]);

  // Main playback loop
  useEffect(() => {
    let animationFrameId: number;
    let lastTime = performance.now();

    const loop = (now: number) => {
      const delta = (now - lastTime) / 1000;
      lastTime = now;

      if (isPlaying) {
        let nextTime = playhead + delta;
        if (nextTime >= projectSettings.duration) {
          if (isLooping) {
            nextTime = 0;
          } else {
            nextTime = projectSettings.duration;
            setIsPlaying(false);
          }
        }
        setPlayhead(nextTime);
      }

      // Draw current frame to preview canvas
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          renderCompositionFrame(
            ctx,
            projectSettings.width,
            projectSettings.height,
            playhead,
            tracks,
            clips,
            assetMap
          );
        }
      }

      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying, playhead, isLooping, projectSettings, tracks, clips, assetMap, setIsPlaying, setPlayhead]);

  // Synchronize audio elements with timeline playback
  useEffect(() => {
    const activeAudios: { audioEl: HTMLAudioElement; clipVolume: number; offset: number }[] = [];

    // Find active audio clips at playhead
    clips.forEach((clip) => {
      if ((clip.type === 'audio' || clip.type === 'video') && clip.assetId && !clip.muted) {
        const track = tracks.find((t) => t.id === clip.trackId);
        if (track && !track.muted && !track.hidden) {
          if (playhead >= clip.startTime && playhead < clip.startTime + clip.duration) {
            const asset = assetMap.get(clip.assetId);
            if (asset) {
              const audioEl = getCachedMediaElement(asset.url, clip.type === 'audio' ? 'audio' : 'video') as HTMLAudioElement;
              const timeOffset = clip.trimIn + (playhead - clip.startTime) * clip.speed;
              activeAudios.push({
                audioEl,
                clipVolume: clip.volume * track.volume * (isMuted ? 0 : 1),
                offset: timeOffset,
              });
            }
          }
        }
      }
    });

    if (isPlaying) {
      activeAudios.forEach(({ audioEl, clipVolume, offset }) => {
        audioEl.volume = Math.max(0, Math.min(1, clipVolume));
        if (Math.abs(audioEl.currentTime - offset) > 0.15) {
          audioEl.currentTime = offset;
        }
        audioEl.play().catch(() => {});
      });
    } else {
      // Pause all audio elements when editor is paused
      assets.forEach((a) => {
        const el = getCachedMediaElement(a.url, a.type === 'audio' ? 'audio' : 'video') as HTMLMediaElement;
        if (el && !el.paused) {
          el.pause();
        }
      });
    }
  }, [isPlaying, playhead, clips, tracks, isMuted, assets, assetMap]);

  // Frame stepping
  const stepFrame = (frames: number) => {
    setIsPlaying(false);
    const frameDuration = 1 / projectSettings.fps;
    setPlayhead(Math.max(0, Math.min(projectSettings.duration, playhead + frames * frameDuration)));
  };

  const jumpToStart = () => {
    setIsPlaying(false);
    setPlayhead(0);
  };

  const jumpToEnd = () => {
    setIsPlaying(false);
    setPlayhead(projectSettings.duration);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const handleAspectRatioChange = (aspect: AspectRatioType) => {
    let width = 1920;
    let height = 1080;
    if (aspect === '9:16') {
      width = 1080;
      height = 1920;
    } else if (aspect === '1:1') {
      width = 1080;
      height = 1080;
    } else if (aspect === '4:5') {
      width = 1080;
      height = 1350;
    }
    updateProjectSettings({ aspectRatio: aspect, width, height });
  };

  // Selected clip overlay calculation
  const selectedClip = clips.find((c) => c.id === selectedClipId);

  return (
    <div
      ref={containerRef}
      className="flex-1 flex flex-col bg-[#08080c] relative overflow-hidden select-none border-b border-[#232633]"
    >
      {/* Top Preview Control Bar */}
      <div className="h-9 bg-[#0d0e14] border-b border-[#232633] px-3 flex items-center justify-between z-10">
        {/* Aspect Ratio Selector */}
        <div className="flex items-center space-x-1.5">
          <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Aspect:</span>
          {(['16:9', '9:16', '1:1', '4:5'] as AspectRatioType[]).map((aspect) => (
            <button
              key={aspect}
              onClick={() => handleAspectRatioChange(aspect)}
              className={`px-2 py-0.5 rounded text-[10px] font-mono font-medium transition-colors ${
                projectSettings.aspectRatio === aspect
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#181a24]'
              }`}
            >
              {aspect}
            </button>
          ))}
        </div>

        {/* Resolution Badge & Scale */}
        <div className="flex items-center space-x-2">
          <div className="text-[10px] text-slate-400 font-mono bg-[#141520] px-2 py-0.5 rounded border border-[#232633]">
            {projectSettings.width} × {projectSettings.height} ({projectSettings.fps}fps)
          </div>

          <button
            onClick={toggleFullscreen}
            title="Toggle Fullscreen"
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-[#1a1b26] transition-colors"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Viewport Stage */}
      <div className="flex-1 flex items-center justify-center p-4 relative overflow-hidden bg-[#07070a]">
        {/* Video Canvas Container */}
        <div
          className="relative max-w-full max-h-full flex items-center justify-center shadow-2xl shadow-black border border-[#232633] bg-black"
          style={{
            aspectRatio: `${projectSettings.width} / ${projectSettings.height}`,
            maxHeight: 'calc(100% - 10px)',
          }}
        >
          <canvas
            ref={canvasRef}
            width={projectSettings.width}
            height={projectSettings.height}
            className="w-full h-full object-contain block"
          />

          {/* Selected Clip Interactive Transform Box (Visual Guide) */}
          {selectedClip && selectedClip.type !== 'audio' && (
            <div
              className="absolute inset-0 pointer-events-none border border-indigo-500/40 rounded-sm"
              style={{
                opacity: selectedClip.transform.opacity,
                transform: `translate(${selectedClip.transform.x}px, ${selectedClip.transform.y}px) rotate(${selectedClip.transform.rotation}deg) scale(${selectedClip.transform.scale})`,
              }}
            >
              <div className="absolute top-1 left-1 bg-indigo-600/80 text-white font-mono text-[9px] px-1 rounded">
                {selectedClip.name} ({Math.round(selectedClip.transform.scale * 100)}%)
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Transport Controls */}
      <div className="h-11 bg-[#0e0f16] border-t border-[#232633] px-4 flex items-center justify-between shrink-0 z-10">
        {/* Left: Timecode Indicator */}
        <div className="flex items-center space-x-2 font-mono text-xs">
          <span className="text-white font-medium">{formatTimecode(playhead, projectSettings.fps)}</span>
          <span className="text-slate-600">/</span>
          <span className="text-slate-500">{formatTimecode(projectSettings.duration, projectSettings.fps)}</span>
        </div>

        {/* Center: Playback Buttons */}
        <div className="flex items-center space-x-1">
          <button
            onClick={jumpToStart}
            title="Jump to Start (Home)"
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-[#1c1e2a] transition-colors"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => stepFrame(-1)}
            title="Step 1 Frame Backward (Left Arrow)"
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-[#1c1e2a] transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Primary Play/Pause Button */}
          <button
            onClick={togglePlay}
            title="Play/Pause (Space)"
            className="w-8 h-8 rounded-full bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white flex items-center justify-center shadow-lg shadow-indigo-600/30 transition-all active:scale-95"
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
          </button>

          <button
            onClick={() => stepFrame(1)}
            title="Step 1 Frame Forward (Right Arrow)"
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-[#1c1e2a] transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            onClick={jumpToEnd}
            title="Jump to End (End)"
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-[#1c1e2a] transition-colors"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right: Loop & Audio Toggle */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsLooping(!isLooping)}
            title={`Loop Playback: ${isLooping ? 'On' : 'Off'}`}
            className={`p-1.5 rounded transition-colors ${
              isLooping ? 'text-indigo-400 bg-indigo-950/40' : 'text-slate-400 hover:text-white hover:bg-[#1c1e2a]'
            }`}
          >
            <Repeat className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsMuted(!isMuted)}
            title={isMuted ? 'Unmute Master' : 'Mute Master'}
            className={`p-1.5 rounded transition-colors ${
              isMuted ? 'text-rose-400 bg-rose-950/40' : 'text-slate-400 hover:text-white hover:bg-[#1c1e2a]'
            }`}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
