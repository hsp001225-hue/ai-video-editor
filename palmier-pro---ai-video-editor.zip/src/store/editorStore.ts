import { create } from 'zustand';
import {
  TimelineClip,
  TimelineTrack,
  TimelineMarker,
  MediaAsset,
  ProjectSettings,
  HistoryState,
  Transform,
  VideoFilters,
  AspectRatioType,
  ClipTransition,
} from '../types/editor';
import { INITIAL_ASSETS } from '../lib/sampleAssets';

const DEFAULT_TRANSFORM: Transform = {
  x: 0,
  y: 0,
  scale: 1,
  rotation: 0,
  opacity: 1,
};

const DEFAULT_FILTERS: VideoFilters = {
  brightness: 100,
  contrast: 100,
  saturation: 100,
  blur: 0,
  sepia: 0,
  grayscale: 0,
};

const INITIAL_TRACKS: TimelineTrack[] = [
  { id: 'track-v2', name: 'Overlay V2', type: 'video', muted: false, locked: false, hidden: false, volume: 1 },
  { id: 'track-v1', name: 'Main Video V1', type: 'video', muted: false, locked: false, hidden: false, volume: 1 },
  { id: 'track-t1', name: 'Titles & Text', type: 'overlay', muted: false, locked: false, hidden: false, volume: 1 },
  { id: 'track-a1', name: 'Audio & Music A1', type: 'audio', muted: false, locked: false, hidden: false, volume: 0.8 },
];

const INITIAL_CLIPS: TimelineClip[] = [
  {
    id: 'clip-v1-1',
    trackId: 'track-v1',
    assetId: 'asset-nature-1',
    type: 'video',
    name: 'Cinematic Mountain Drone',
    startTime: 0,
    duration: 6.0,
    trimIn: 0,
    trimOut: 6.0,
    speed: 1.0,
    volume: 1.0,
    muted: false,
    transform: { ...DEFAULT_TRANSFORM },
    filters: { ...DEFAULT_FILTERS },
    color: '#3b82f6',
  },
  {
    id: 'clip-v1-2',
    trackId: 'track-v1',
    assetId: 'asset-city-2',
    type: 'video',
    name: 'Cyberpunk Neon City',
    startTime: 6.0,
    duration: 7.0,
    trimIn: 1.0,
    trimOut: 8.0,
    speed: 1.0,
    volume: 1.0,
    muted: false,
    transform: { ...DEFAULT_TRANSFORM },
    filters: { ...DEFAULT_FILTERS, contrast: 110, saturation: 115 },
    color: '#3b82f6',
  },
  {
    id: 'clip-t1-1',
    trackId: 'track-t1',
    type: 'text',
    name: 'Title: CINEMATIC REEL',
    startTime: 0.5,
    duration: 4.5,
    trimIn: 0,
    trimOut: 4.5,
    speed: 1.0,
    volume: 1.0,
    muted: false,
    transform: { ...DEFAULT_TRANSFORM, y: 35 },
    filters: { ...DEFAULT_FILTERS },
    textConfig: {
      text: 'PALMIER PRO // CINEMATIC',
      fontSize: 48,
      fontFamily: 'Plus Jakarta Sans',
      fontWeight: 'bold',
      color: '#ffffff',
      backgroundColor: 'rgba(0, 0, 0, 0.45)',
      textAlign: 'center',
      shadow: true,
    },
    color: '#f59e0b',
  },
  {
    id: 'clip-a1-1',
    trackId: 'track-a1',
    assetId: 'asset-audio-lofi',
    type: 'audio',
    name: 'Sunset Lofi Chill Beat',
    startTime: 0,
    duration: 13.0,
    trimIn: 0,
    trimOut: 13.0,
    speed: 1.0,
    volume: 0.75,
    muted: false,
    transform: { ...DEFAULT_TRANSFORM },
    filters: { ...DEFAULT_FILTERS },
    color: '#10b981',
  },
];

const INITIAL_MARKERS: TimelineMarker[] = [
  { id: 'marker-1', time: 6.0, label: 'Cut: Neon City', color: '#f43f5e' },
  { id: 'marker-2', time: 13.0, label: 'Audio Outro', color: '#10b981' },
];

interface EditorStoreState {
  // Timeline State
  playhead: number;
  isPlaying: boolean;
  zoom: number; // pixels per second
  selectedClipId: string | null;
  selectedTrackId: string | null;
  snappingEnabled: boolean;
  isSaving: boolean;
  lastSavedAt: Date | null;

  // Project data
  projectSettings: ProjectSettings;
  tracks: TimelineTrack[];
  clips: TimelineClip[];
  markers: TimelineMarker[];
  assets: MediaAsset[];

  // Undo / Redo history
  historyPast: HistoryState[];
  historyFuture: HistoryState[];

  // Actions
  setPlayhead: (time: number) => void;
  setIsPlaying: (playing: boolean) => void;
  togglePlay: () => void;
  setZoom: (zoom: number) => void;
  selectClip: (id: string | null) => void;
  selectTrack: (id: string | null) => void;
  setSnappingEnabled: (enabled: boolean) => void;

  // Clip actions
  addClip: (clip: Omit<TimelineClip, 'id'>) => string;
  updateClip: (id: string, updates: Partial<TimelineClip>) => void;
  deleteClip: (id: string) => void;
  splitClip: (id: string, atTime?: number) => void;
  moveClip: (id: string, newStartTime: number, newTrackId?: string) => void;
  trimClip: (id: string, newTrimIn: number, newTrimOut: number, newStartTime?: number) => void;
  duplicateClip: (id: string) => void;

  // Track actions
  addTrack: (type: 'video' | 'audio' | 'overlay', name?: string) => void;
  updateTrack: (id: string, updates: Partial<TimelineTrack>) => void;
  deleteTrack: (id: string) => void;

  // Marker actions
  addMarker: (time: number, label: string, color?: string) => string;
  deleteMarker: (id: string) => void;

  // Asset actions
  addAsset: (asset: MediaAsset) => void;
  deleteAsset: (id: string) => void;

  // Project settings
  updateProjectSettings: (updates: Partial<ProjectSettings>) => void;

  // History
  undo: () => void;
  redo: () => void;
  saveSnapshot: () => void;
}

export const useEditorStore = create<EditorStoreState>((set, get) => ({
  playhead: 0,
  isPlaying: false,
  zoom: 45, // 45px per second
  selectedClipId: 'clip-v1-1',
  selectedTrackId: 'track-v1',
  snappingEnabled: true,
  isSaving: false,
  lastSavedAt: new Date(),

  projectSettings: {
    name: 'Untitled Cinematic Project',
    width: 1920,
    height: 1080,
    fps: 30,
    duration: 30,
    aspectRatio: '16:9',
    backgroundColor: '#000000',
    snapTolerance: 0.15,
  },

  tracks: INITIAL_TRACKS,
  clips: INITIAL_CLIPS,
  markers: INITIAL_MARKERS,
  assets: INITIAL_ASSETS,

  historyPast: [],
  historyFuture: [],

  setPlayhead: (time) => {
    const clamped = Math.max(0, Math.min(time, get().projectSettings.duration));
    set({ playhead: clamped });
  },

  setIsPlaying: (playing) => set({ isPlaying: playing }),

  togglePlay: () => set((state) => ({ isPlaying: !state.isPlaying })),

  setZoom: (zoom) => {
    const clamped = Math.max(15, Math.min(150, zoom));
    set({ zoom: clamped });
  },

  selectClip: (id) => set({ selectedClipId: id }),

  selectTrack: (id) => set({ selectedTrackId: id }),

  setSnappingEnabled: (enabled) => set({ snappingEnabled: enabled }),

  saveSnapshot: () => {
    const { tracks, clips, markers, projectSettings, historyPast } = get();
    const newSnapshot: HistoryState = {
      tracks: JSON.parse(JSON.stringify(tracks)),
      clips: JSON.parse(JSON.stringify(clips)),
      markers: JSON.parse(JSON.stringify(markers)),
      projectSettings: JSON.parse(JSON.stringify(projectSettings)),
    };
    // keep maximum 30 history states
    const updatedPast = [...historyPast, newSnapshot].slice(-30);
    set({
      historyPast: updatedPast,
      historyFuture: [],
      lastSavedAt: new Date(),
    });
  },

  addClip: (clipData) => {
    get().saveSnapshot();
    const id = `clip-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newClip: TimelineClip = {
      ...clipData,
      id,
    };
    set((state) => ({
      clips: [...state.clips, newClip],
      selectedClipId: id,
    }));
    return id;
  },

  updateClip: (id, updates) => {
    set((state) => ({
      clips: state.clips.map((c) => (c.id === id ? { ...c, ...updates } : c)),
      lastSavedAt: new Date(),
    }));
  },

  deleteClip: (id) => {
    get().saveSnapshot();
    set((state) => ({
      clips: state.clips.filter((c) => c.id !== id),
      selectedClipId: state.selectedClipId === id ? null : state.selectedClipId,
      lastSavedAt: new Date(),
    }));
  },

  splitClip: (id, atTime) => {
    const { clips, playhead, saveSnapshot } = get();
    const clip = clips.find((c) => c.id === id);
    if (!clip) return;

    const splitPoint = atTime !== undefined ? atTime : playhead;
    if (splitPoint <= clip.startTime || splitPoint >= clip.startTime + clip.duration) {
      return;
    }

    saveSnapshot();

    const timeOffsetInClip = splitPoint - clip.startTime;
    const firstDuration = timeOffsetInClip;
    const secondDuration = clip.duration - timeOffsetInClip;

    const firstClip: TimelineClip = {
      ...clip,
      duration: firstDuration,
      trimOut: clip.trimIn + firstDuration * clip.speed,
    };

    const secondClipId = `clip-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const secondClip: TimelineClip = {
      ...clip,
      id: secondClipId,
      name: `${clip.name} (Part 2)`,
      startTime: splitPoint,
      duration: secondDuration,
      trimIn: clip.trimIn + firstDuration * clip.speed,
      trimOut: clip.trimOut,
    };

    set((state) => ({
      clips: state.clips.map((c) => (c.id === id ? firstClip : c)).concat(secondClip),
      selectedClipId: secondClipId,
      lastSavedAt: new Date(),
    }));
  },

  moveClip: (id, newStartTime, newTrackId) => {
    const { clips, snappingEnabled, projectSettings } = get();
    let targetStart = Math.max(0, newStartTime);

    // Magnet snapping
    if (snappingEnabled) {
      const snapPoints: number[] = [0, get().playhead];
      clips.forEach((c) => {
        if (c.id !== id) {
          snapPoints.push(c.startTime);
          snapPoints.push(c.startTime + c.duration);
        }
      });

      const currentClip = clips.find((c) => c.id === id);
      const clipDuration = currentClip ? currentClip.duration : 0;

      for (const pt of snapPoints) {
        if (Math.abs(targetStart - pt) < projectSettings.snapTolerance) {
          targetStart = pt;
          break;
        }
        if (Math.abs(targetStart + clipDuration - pt) < projectSettings.snapTolerance) {
          targetStart = pt - clipDuration;
          break;
        }
      }
    }

    set((state) => ({
      clips: state.clips.map((c) =>
        c.id === id
          ? {
              ...c,
              startTime: targetStart,
              trackId: newTrackId || c.trackId,
            }
          : c
      ),
      lastSavedAt: new Date(),
    }));
  },

  trimClip: (id, newTrimIn, newTrimOut, newStartTime) => {
    set((state) => ({
      clips: state.clips.map((c) => {
        if (c.id !== id) return c;
        const duration = (newTrimOut - newTrimIn) / c.speed;
        return {
          ...c,
          trimIn: Math.max(0, newTrimIn),
          trimOut: Math.max(newTrimIn + 0.1, newTrimOut),
          duration: Math.max(0.1, duration),
          startTime: newStartTime !== undefined ? Math.max(0, newStartTime) : c.startTime,
        };
      }),
      lastSavedAt: new Date(),
    }));
  },

  duplicateClip: (id) => {
    const { clips, saveSnapshot } = get();
    const clip = clips.find((c) => c.id === id);
    if (!clip) return;

    saveSnapshot();
    const newId = `clip-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const duplicated: TimelineClip = {
      ...JSON.parse(JSON.stringify(clip)),
      id: newId,
      name: `${clip.name} (Copy)`,
      startTime: clip.startTime + clip.duration + 0.5,
    };

    set((state) => ({
      clips: [...state.clips, duplicated],
      selectedClipId: newId,
      lastSavedAt: new Date(),
    }));
  },

  addTrack: (type, name) => {
    get().saveSnapshot();
    const count = get().tracks.filter((t) => t.type === type).length + 1;
    const prefix = type === 'video' ? 'V' : type === 'audio' ? 'A' : 'T';
    const newTrack: TimelineTrack = {
      id: `track-${prefix.toLowerCase()}${Date.now().toString().slice(-4)}`,
      name: name || `${type.charAt(0).toUpperCase() + type.slice(1)} ${prefix}${count}`,
      type,
      muted: false,
      locked: false,
      hidden: false,
      volume: 1.0,
    };
    set((state) => ({
      tracks: [newTrack, ...state.tracks],
      lastSavedAt: new Date(),
    }));
  },

  updateTrack: (id, updates) => {
    set((state) => ({
      tracks: state.tracks.map((t) => (t.id === id ? { ...t, ...updates } : t)),
      lastSavedAt: new Date(),
    }));
  },

  deleteTrack: (id) => {
    get().saveSnapshot();
    set((state) => ({
      tracks: state.tracks.filter((t) => t.id !== id),
      clips: state.clips.filter((c) => c.trackId !== id),
      selectedTrackId: state.selectedTrackId === id ? null : state.selectedTrackId,
      lastSavedAt: new Date(),
    }));
  },

  addMarker: (time, label, color = '#f43f5e') => {
    get().saveSnapshot();
    const id = `marker-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const newMarker: TimelineMarker = {
      id,
      time: Math.max(0, Math.min(get().projectSettings.duration, time)),
      label,
      color,
    };
    set((state) => ({
      markers: [...state.markers, newMarker].sort((a, b) => a.time - b.time),
      lastSavedAt: new Date(),
    }));
    return id;
  },

  deleteMarker: (id) => {
    get().saveSnapshot();
    set((state) => ({
      markers: state.markers.filter((m) => m.id !== id),
      lastSavedAt: new Date(),
    }));
  },

  addAsset: (asset) => {
    set((state) => ({
      assets: [asset, ...state.assets],
    }));
  },

  deleteAsset: (id) => {
    set((state) => ({
      assets: state.assets.filter((a) => a.id !== id),
    }));
  },

  updateProjectSettings: (updates) => {
    set((state) => ({
      projectSettings: { ...state.projectSettings, ...updates },
      lastSavedAt: new Date(),
    }));
  },

  undo: () => {
    const { historyPast, historyFuture, tracks, clips, markers, projectSettings } = get();
    if (historyPast.length === 0) return;

    const previous = historyPast[historyPast.length - 1];
    const newPast = historyPast.slice(0, -1);
    const currentSnapshot: HistoryState = {
      tracks: JSON.parse(JSON.stringify(tracks)),
      clips: JSON.parse(JSON.stringify(clips)),
      markers: JSON.parse(JSON.stringify(markers)),
      projectSettings: JSON.parse(JSON.stringify(projectSettings)),
    };

    set({
      tracks: previous.tracks,
      clips: previous.clips,
      markers: previous.markers || [],
      projectSettings: previous.projectSettings || projectSettings,
      historyPast: newPast,
      historyFuture: [currentSnapshot, ...historyFuture],
      lastSavedAt: new Date(),
    });
  },

  redo: () => {
    const { historyPast, historyFuture, tracks, clips, markers, projectSettings } = get();
    if (historyFuture.length === 0) return;

    const next = historyFuture[0];
    const newFuture = historyFuture.slice(1);
    const currentSnapshot: HistoryState = {
      tracks: JSON.parse(JSON.stringify(tracks)),
      clips: JSON.parse(JSON.stringify(clips)),
      markers: JSON.parse(JSON.stringify(markers)),
      projectSettings: JSON.parse(JSON.stringify(projectSettings)),
    };

    set({
      tracks: next.tracks,
      clips: next.clips,
      markers: next.markers || [],
      projectSettings: next.projectSettings || projectSettings,
      historyPast: [...historyPast, currentSnapshot],
      historyFuture: newFuture,
      lastSavedAt: new Date(),
    });
  },
}));
