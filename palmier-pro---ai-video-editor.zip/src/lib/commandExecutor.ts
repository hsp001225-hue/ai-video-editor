import { useEditorStore } from '../store/editorStore';
import {
  EditingCommand,
  CommandExecutionResult,
  TimelineClip,
  TimelineMarker,
  AspectRatioType,
  ClipTransition,
} from '../types/editor';

/**
 * Centralized Command Executor.
 * Interprets validated JSON editing operations and applies them to the editor state.
 *
 * Enforces:
 * - Unique IDs for all clips and markers
 * - Valid clip references
 * - Non-negative durations and valid timeline boundaries
 * - Undo / Redo history preservation
 * - Safe, isolated execution (no arbitrary code execution)
 */
export function executeEditingCommand(command: EditingCommand): CommandExecutionResult {
  const store = useEditorStore.getState();

  try {
    switch (command.type) {
      case 'undo': {
        if (store.historyPast.length === 0) {
          return {
            success: false,
            commandType: 'undo',
            message: 'Nothing to undo in history stack.',
            error: 'History stack is empty',
          };
        }
        store.undo();
        return {
          success: true,
          commandType: 'undo',
          message: 'Undid last editor action.',
        };
      }

      case 'redo': {
        if (store.historyFuture.length === 0) {
          return {
            success: false,
            commandType: 'redo',
            message: 'Nothing to redo in history stack.',
            error: 'Redo stack is empty',
          };
        }
        store.redo();
        return {
          success: true,
          commandType: 'redo',
          message: 'Redid previously undone action.',
        };
      }

      case 'add_clip': {
        store.saveSnapshot();
        const asset = store.assets.find((a) => a.id === command.assetId) || store.assets[0];
        let targetTrack = command.trackId
          ? store.tracks.find((t) => t.id === command.trackId)
          : undefined;

        if (!targetTrack) {
          targetTrack =
            asset?.type === 'audio'
              ? store.tracks.find((t) => t.type === 'audio')
              : store.tracks.find((t) => t.type === 'video');
        }
        if (!targetTrack) targetTrack = store.tracks[0];

        const duration = Math.max(0.1, command.duration || Math.min(asset?.duration || 6, 6));
        const startTime = Math.max(0, command.startTime);

        const newClipId = `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const newClip: TimelineClip = {
          id: newClipId,
          trackId: targetTrack.id,
          assetId: asset?.id,
          type: asset?.type || 'video',
          name: command.name || asset?.name || 'Added Clip',
          startTime,
          duration,
          trimIn: 0,
          trimOut: duration,
          speed: 1.0,
          volume: asset?.type === 'audio' ? 0.8 : 1.0,
          muted: false,
          transform: { x: 0, y: 0, scale: 1, rotation: 0, opacity: 1 },
          filters: { brightness: 100, contrast: 100, saturation: 100, blur: 0, sepia: 0, grayscale: 0 },
          color: asset?.type === 'audio' ? '#10b981' : asset?.type === 'image' ? '#8b5cf6' : '#3b82f6',
        };

        // Adjust project duration if clip exceeds current boundary
        if (startTime + duration > store.projectSettings.duration) {
          store.updateProjectSettings({ duration: Math.ceil(startTime + duration + 5) });
        }

        useEditorStore.setState((state) => ({
          clips: [...state.clips, newClip],
          selectedClipId: newClipId,
          lastSavedAt: new Date(),
        }));

        return {
          success: true,
          commandType: 'add_clip',
          message: `Added clip "${newClip.name}" at ${startTime.toFixed(2)}s on ${targetTrack.name}.`,
          affectedClipId: newClipId,
        };
      }

      case 'remove_clip': {
        const target = store.clips.find((c) => c.id === command.clipId);
        if (!target) {
          return {
            success: false,
            commandType: 'remove_clip',
            message: `Clip "${command.clipId}" could not be found.`,
            error: 'Clip not found',
          };
        }

        store.deleteClip(target.id);
        return {
          success: true,
          commandType: 'remove_clip',
          message: `Removed clip "${target.name}".`,
          affectedClipId: target.id,
        };
      }

      case 'move_clip': {
        const target = store.clips.find((c) => c.id === command.clipId);
        if (!target) {
          return {
            success: false,
            commandType: 'move_clip',
            message: `Clip "${command.clipId}" not found.`,
            error: 'Clip reference invalid',
          };
        }

        const newStartTime = Math.max(0, command.startTime);
        store.saveSnapshot();

        // Adjust project duration if needed
        if (newStartTime + target.duration > store.projectSettings.duration) {
          store.updateProjectSettings({ duration: Math.ceil(newStartTime + target.duration + 5) });
        }

        store.moveClip(target.id, newStartTime, command.trackId);
        return {
          success: true,
          commandType: 'move_clip',
          message: `Moved clip "${target.name}" to ${newStartTime.toFixed(2)}s.`,
          affectedClipId: target.id,
        };
      }

      case 'trim_clip': {
        const target = store.clips.find((c) => c.id === command.clipId);
        if (!target) {
          return {
            success: false,
            commandType: 'trim_clip',
            message: `Clip "${command.clipId}" not found.`,
            error: 'Clip reference invalid',
          };
        }

        store.saveSnapshot();
        const trimIn = command.trimIn !== undefined ? Math.max(0, command.trimIn) : target.trimIn;
        const trimOut =
          command.trimOut !== undefined ? Math.max(trimIn + 0.1, command.trimOut) : target.trimOut;
        const startTime = command.startTime !== undefined ? Math.max(0, command.startTime) : target.startTime;

        store.trimClip(target.id, trimIn, trimOut, startTime);
        return {
          success: true,
          commandType: 'trim_clip',
          message: `Trimmed "${target.name}" (trimIn: ${trimIn.toFixed(2)}s, trimOut: ${trimOut.toFixed(2)}s).`,
          affectedClipId: target.id,
        };
      }

      case 'split_clip': {
        const target = store.clips.find((c) => c.id === command.clipId);
        if (!target) {
          return {
            success: false,
            commandType: 'split_clip',
            message: `Clip "${command.clipId}" not found.`,
            error: 'Clip reference invalid',
          };
        }

        const splitAt = command.splitTime !== undefined ? command.splitTime : store.playhead;
        if (splitAt <= target.startTime || splitAt >= target.startTime + target.duration) {
          return {
            success: false,
            commandType: 'split_clip',
            message: `Split position ${splitAt.toFixed(2)}s is outside clip boundaries [${target.startTime.toFixed(2)}s - ${(target.startTime + target.duration).toFixed(2)}s].`,
            error: 'Split position out of bounds',
          };
        }

        store.splitClip(target.id, splitAt);
        return {
          success: true,
          commandType: 'split_clip',
          message: `Split "${target.name}" at ${splitAt.toFixed(2)}s.`,
          affectedClipId: target.id,
        };
      }

      case 'resize_clip': {
        const target = store.clips.find((c) => c.id === command.clipId);
        if (!target) {
          return {
            success: false,
            commandType: 'resize_clip',
            message: `Clip "${command.clipId}" not found.`,
            error: 'Clip not found',
          };
        }

        store.saveSnapshot();
        const updates: Partial<TimelineClip> = {};

        if (command.duration !== undefined) {
          const newDur = Math.max(0.1, command.duration);
          updates.duration = newDur;
          updates.trimOut = target.trimIn + newDur * target.speed;
        }

        if (command.scale !== undefined) {
          updates.transform = {
            ...target.transform,
            scale: Math.max(0.1, Math.min(5.0, command.scale)),
          };
        }

        store.updateClip(target.id, updates);
        return {
          success: true,
          commandType: 'resize_clip',
          message: `Resized clip "${target.name}".`,
          affectedClipId: target.id,
        };
      }

      case 'change_volume': {
        const target = store.clips.find((c) => c.id === command.clipId);
        if (!target) {
          return {
            success: false,
            commandType: 'change_volume',
            message: `Clip "${command.clipId}" not found.`,
            error: 'Clip reference invalid',
          };
        }

        store.saveSnapshot();
        const vol = Math.max(0, Math.min(2.0, command.volume));
        store.updateClip(target.id, { volume: vol });
        return {
          success: true,
          commandType: 'change_volume',
          message: `Set volume of "${target.name}" to ${Math.round(vol * 100)}%.`,
          affectedClipId: target.id,
        };
      }

      case 'change_speed': {
        const target = store.clips.find((c) => c.id === command.clipId);
        if (!target) {
          return {
            success: false,
            commandType: 'change_speed',
            message: `Clip "${command.clipId}" not found.`,
            error: 'Clip reference invalid',
          };
        }

        store.saveSnapshot();
        const speed = Math.max(0.25, Math.min(4.0, command.speed));
        const newDuration = (target.trimOut - target.trimIn) / speed;
        store.updateClip(target.id, { speed, duration: newDuration });
        return {
          success: true,
          commandType: 'change_speed',
          message: `Adjusted speed of "${target.name}" to ${speed}x (new duration: ${newDuration.toFixed(2)}s).`,
          affectedClipId: target.id,
        };
      }

      case 'add_transition': {
        const target = store.clips.find((c) => c.id === command.clipId);
        if (!target) {
          return {
            success: false,
            commandType: 'add_transition',
            message: `Clip "${command.clipId}" not found.`,
            error: 'Clip reference invalid',
          };
        }

        store.saveSnapshot();
        const transition: ClipTransition = {
          type: command.transitionType,
          duration: Math.max(0.1, Math.min(target.duration, command.duration || 1.0)),
          position: command.position || 'both',
        };

        store.updateClip(target.id, { transition });
        return {
          success: true,
          commandType: 'add_transition',
          message: `Applied ${command.transitionType} transition (${transition.duration}s) to "${target.name}".`,
          affectedClipId: target.id,
        };
      }

      case 'add_text': {
        store.saveSnapshot();
        const overlayTrack = store.tracks.find((t) => t.type === 'overlay') || store.tracks[0];
        const startTime = Math.max(0, command.startTime !== undefined ? command.startTime : store.playhead);
        const duration = Math.max(0.5, command.duration || 4.0);

        const newId = `clip-text-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const textClip: TimelineClip = {
          id: newId,
          trackId: overlayTrack.id,
          type: 'text',
          name: `Text: ${command.text.slice(0, 24)}`,
          startTime,
          duration,
          trimIn: 0,
          trimOut: duration,
          speed: 1.0,
          volume: 1.0,
          muted: false,
          transform: { x: 0, y: command.positionY !== undefined ? command.positionY : 35, scale: 1, rotation: 0, opacity: 1 },
          filters: { brightness: 100, contrast: 100, saturation: 100, blur: 0, sepia: 0, grayscale: 0 },
          textConfig: {
            text: command.text,
            fontSize: command.fontSize || 48,
            fontFamily: 'Plus Jakarta Sans',
            fontWeight: 'bold',
            color: command.color || '#ffffff',
            backgroundColor: command.backgroundColor || 'rgba(0, 0, 0, 0.55)',
            textAlign: 'center',
            shadow: true,
          },
          color: '#f59e0b',
        };

        useEditorStore.setState((state) => ({
          clips: [...state.clips, textClip],
          selectedClipId: newId,
          lastSavedAt: new Date(),
        }));

        return {
          success: true,
          commandType: 'add_text',
          message: `Added title "${command.text}" at ${startTime.toFixed(2)}s.`,
          affectedClipId: newId,
        };
      }

      case 'add_audio': {
        store.saveSnapshot();
        const audioAsset =
          (command.assetId ? store.assets.find((a) => a.id === command.assetId) : undefined) ||
          store.assets.find((a) => a.type === 'audio') ||
          store.assets[0];

        const audioTrack =
          (command.trackId ? store.tracks.find((t) => t.id === command.trackId) : undefined) ||
          store.tracks.find((t) => t.type === 'audio') ||
          store.tracks[0];

        const startTime = Math.max(0, command.startTime !== undefined ? command.startTime : store.playhead);
        const duration = Math.max(0.5, command.duration || audioAsset?.duration || 10.0);
        const volume = command.volume !== undefined ? Math.max(0, Math.min(2.0, command.volume)) : 0.8;

        const newId = `clip-audio-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const audioClip: TimelineClip = {
          id: newId,
          trackId: audioTrack.id,
          assetId: audioAsset?.id,
          type: 'audio',
          name: audioAsset?.name || 'Background Audio',
          startTime,
          duration,
          trimIn: 0,
          trimOut: duration,
          speed: 1.0,
          volume,
          muted: false,
          transform: { x: 0, y: 0, scale: 1, rotation: 0, opacity: 1 },
          filters: { brightness: 100, contrast: 100, saturation: 100, blur: 0, sepia: 0, grayscale: 0 },
          color: '#10b981',
        };

        useEditorStore.setState((state) => ({
          clips: [...state.clips, audioClip],
          selectedClipId: newId,
          lastSavedAt: new Date(),
        }));

        return {
          success: true,
          commandType: 'add_audio',
          message: `Added audio "${audioClip.name}" at ${startTime.toFixed(2)}s on ${audioTrack.name}.`,
          affectedClipId: newId,
        };
      }

      case 'add_marker': {
        store.saveSnapshot();
        const time = Math.max(0, Math.min(store.projectSettings.duration, command.time));
        const markerId = `marker-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const newMarker: TimelineMarker = {
          id: markerId,
          time,
          label: command.label || `Marker @ ${time.toFixed(1)}s`,
          color: command.color || '#f43f5e',
        };

        useEditorStore.setState((state) => ({
          markers: [...state.markers, newMarker].sort((a, b) => a.time - b.time),
          lastSavedAt: new Date(),
        }));

        return {
          success: true,
          commandType: 'add_marker',
          message: `Placed marker "${newMarker.label}" at ${time.toFixed(2)}s.`,
        };
      }

      case 'change_aspect_ratio': {
        store.saveSnapshot();
        const aspect = command.aspectRatio;
        let width = 1920;
        let height = 1080;
        if (aspect === '9:16') {
          width = 1080;
          height = 1920;
        } else if (aspect === '1:1') {
          width = 1080;
          height = 1080;
        } else if (aspect === '4:5') {
          width = 1080;
          height = 1350;
        } else if (aspect === '21:9') {
          width = 2560;
          height = 1080;
        }

        store.updateProjectSettings({ aspectRatio: aspect, width, height });
        return {
          success: true,
          commandType: 'change_aspect_ratio',
          message: `Changed aspect ratio to ${aspect} (${width}x${height}).`,
        };
      }

      default:
        return {
          success: false,
          commandType: (command as any).type,
          message: `Unknown command type "${(command as any).type}".`,
          error: 'Unsupported command',
        };
    }
  } catch (err: any) {
    return {
      success: false,
      commandType: command.type,
      message: `Failed to execute ${command.type}: ${err.message || 'Internal error'}`,
      error: err.message || 'Execution error',
    };
  }
}

/**
 * Executes a batch of commands sequentially.
 * If any command fails, logs error and stops, preserving previous successful operations in history.
 */
export function executeCommandBatch(commands: EditingCommand[]): CommandExecutionResult[] {
  const results: CommandExecutionResult[] = [];
  for (const cmd of commands) {
    const res = executeEditingCommand(cmd);
    results.push(res);
    if (!res.success) {
      break;
    }
  }
  return results;
}
