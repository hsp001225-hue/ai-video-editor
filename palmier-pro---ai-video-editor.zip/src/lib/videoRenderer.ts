import { TimelineClip, TimelineTrack, VideoFilters, Transform, TextConfig } from '../types/editor';

// Cache for video/image elements to avoid re-creating DOM elements on every render tick
const mediaElementsCache = new Map<string, HTMLVideoElement | HTMLImageElement | HTMLAudioElement>();

export function getCachedMediaElement(url: string, type: 'video' | 'image' | 'audio') {
  if (mediaElementsCache.has(url)) {
    return mediaElementsCache.get(url)!;
  }

  if (type === 'video') {
    const video = document.createElement('video');
    video.src = url;
    video.crossOrigin = 'anonymous';
    video.playsInline = true;
    video.muted = true; // Muted in cache; audio handled separately
    video.preload = 'auto';
    mediaElementsCache.set(url, video);
    return video;
  } else if (type === 'image') {
    const img = new Image();
    img.src = url;
    img.crossOrigin = 'anonymous';
    mediaElementsCache.set(url, img);
    return img;
  } else {
    const audio = new Audio();
    audio.src = url;
    audio.crossOrigin = 'anonymous';
    audio.preload = 'auto';
    mediaElementsCache.set(url, audio);
    return audio;
  }
}

/**
 * Builds CSS filter string from VideoFilters object
 */
export function buildFilterString(filters: VideoFilters): string {
  const parts: string[] = [];
  if (filters.brightness !== 100) parts.push(`brightness(${filters.brightness}%)`);
  if (filters.contrast !== 100) parts.push(`contrast(${filters.contrast}%)`);
  if (filters.saturation !== 100) parts.push(`saturate(${filters.saturation}%)`);
  if (filters.blur > 0) parts.push(`blur(${filters.blur}px)`);
  if (filters.sepia > 0) parts.push(`sepia(${filters.sepia}%)`);
  if (filters.grayscale > 0) parts.push(`grayscale(${filters.grayscale}%)`);
  return parts.length > 0 ? parts.join(' ') : 'none';
}

/**
 * Renders a complete composition frame at time `timeInSeconds` onto target canvas
 */
export function renderCompositionFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  timeInSeconds: number,
  tracks: TimelineTrack[],
  clips: TimelineClip[],
  assetMap: Map<string, { url: string; type: string; name: string }>
) {
  // Clear canvas
  ctx.save();
  ctx.fillStyle = '#0b0c10';
  ctx.fillRect(0, 0, width, height);

  // Background subtle grid/matte
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, width, height);

  // Tracks in reverse order (bottom track renders first, top track overlays on top)
  const sortedTracks = [...tracks].reverse();

  for (const track of sortedTracks) {
    if (track.hidden || track.type === 'audio') continue;

    // Find active clip on this track at current time
    const activeClip = clips.find(
      (c) => c.trackId === track.id && timeInSeconds >= c.startTime && timeInSeconds < c.startTime + c.duration
    );

    if (!activeClip) continue;

    const timeOffsetInClip = timeInSeconds - activeClip.startTime;
    const mediaTime = activeClip.trimIn + timeOffsetInClip * activeClip.speed;

    ctx.save();

    // Calculate transition alpha/transform effects
    let transitionAlpha = 1.0;
    let transitionOffsetX = 0;
    let transitionScale = 1.0;

    if (activeClip.transition) {
      const transDur = Math.max(0.1, activeClip.transition.duration);
      const isIntro = timeOffsetInClip <= transDur && (activeClip.transition.position === 'in' || activeClip.transition.position === 'both');
      const timeRemaining = activeClip.duration - timeOffsetInClip;
      const isOutro = timeRemaining <= transDur && (activeClip.transition.position === 'out' || activeClip.transition.position === 'both');

      if (isIntro) {
        const progress = Math.min(1, Math.max(0, timeOffsetInClip / transDur));
        if (activeClip.transition.type === 'fade' || activeClip.transition.type === 'dissolve') {
          transitionAlpha = progress;
        } else if (activeClip.transition.type === 'slide') {
          transitionOffsetX = -(1 - progress) * width;
        } else if (activeClip.transition.type === 'zoom') {
          transitionScale = 0.6 + 0.4 * progress;
        }
      } else if (isOutro) {
        const progress = Math.min(1, Math.max(0, timeRemaining / transDur));
        if (activeClip.transition.type === 'fade' || activeClip.transition.type === 'dissolve') {
          transitionAlpha = progress;
        } else if (activeClip.transition.type === 'slide') {
          transitionOffsetX = (1 - progress) * width;
        } else if (activeClip.transition.type === 'zoom') {
          transitionScale = 0.6 + 0.4 * progress;
        }
      }
    }

    // Apply clip global alpha (opacity) multiplied with transition alpha
    ctx.globalAlpha = Math.max(0, Math.min(1, activeClip.transform.opacity * transitionAlpha));

    // Calculate center transformation
    const centerX = width / 2 + (activeClip.transform.x / 100) * width + transitionOffsetX;
    const centerY = height / 2 + (activeClip.transform.y / 100) * height;

    ctx.translate(centerX, centerY);
    if (activeClip.transform.rotation !== 0) {
      ctx.rotate((activeClip.transform.rotation * Math.PI) / 180);
    }

    const finalScale = activeClip.transform.scale * transitionScale;
    if (finalScale !== 1) {
      ctx.scale(finalScale, finalScale);
    }

    // Apply filters
    const filterStr = buildFilterString(activeClip.filters);
    if (filterStr !== 'none') {
      ctx.filter = filterStr;
    }

    if (activeClip.type === 'video' && activeClip.assetId) {
      const asset = assetMap.get(activeClip.assetId);
      if (asset) {
        const videoEl = getCachedMediaElement(asset.url, 'video') as HTMLVideoElement;
        if (videoEl) {
          // Seek video to corresponding frame if not playing
          if (Math.abs(videoEl.currentTime - mediaTime) > 0.15 && isFinite(mediaTime)) {
            videoEl.currentTime = mediaTime;
          }
          try {
            // Draw video centered
            ctx.drawImage(videoEl, -width / 2, -height / 2, width, height);
          } catch (e) {
            renderFallbackFrame(ctx, width, height, activeClip.name, timeInSeconds);
          }
        } else {
          renderFallbackFrame(ctx, width, height, activeClip.name, timeInSeconds);
        }
      } else {
        renderFallbackFrame(ctx, width, height, activeClip.name, timeInSeconds);
      }
    } else if (activeClip.type === 'image' && activeClip.assetId) {
      const asset = assetMap.get(activeClip.assetId);
      if (asset) {
        const imgEl = getCachedMediaElement(asset.url, 'image') as HTMLImageElement;
        if (imgEl && imgEl.complete) {
          ctx.drawImage(imgEl, -width / 2, -height / 2, width, height);
        }
      }
    } else if (activeClip.type === 'text' && activeClip.textConfig) {
      renderTextOverlay(ctx, activeClip.textConfig);
    }

    ctx.restore();
  }

  ctx.restore();
}

function renderFallbackFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  name: string,
  time: number
) {
  const grad = ctx.createLinearGradient(-width / 2, -height / 2, width / 2, height / 2);
  grad.addColorStop(0, '#1e1b4b');
  grad.addColorStop(1, '#0f172a');
  ctx.fillStyle = grad;
  ctx.fillRect(-width / 2, -height / 2, width, height);

  ctx.fillStyle = '#6366f1';
  ctx.font = 'bold 36px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(name, 0, -20);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '20px "JetBrains Mono", monospace';
  ctx.fillText(`Timecode: ${time.toFixed(2)}s`, 0, 30);
}

function renderTextOverlay(ctx: CanvasRenderingContext2D, config: TextConfig) {
  ctx.font = `${config.fontWeight} ${config.fontSize}px "${config.fontFamily}", sans-serif`;
  ctx.textAlign = config.textAlign || 'center';
  ctx.textBaseline = 'middle';

  const metrics = ctx.measureText(config.text);
  const textWidth = metrics.width;
  const textHeight = config.fontSize * 1.2;

  // Background Box
  if (config.backgroundColor && config.backgroundColor !== 'transparent') {
    ctx.fillStyle = config.backgroundColor;
    const paddingX = 24;
    const paddingY = 12;
    const boxX = config.textAlign === 'center' ? -textWidth / 2 - paddingX : -paddingX;
    const boxY = -textHeight / 2 - paddingY / 2;
    const boxW = textWidth + paddingX * 2;
    const boxH = textHeight + paddingY;

    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxW, boxH, 8);
    ctx.fill();
  }

  // Shadow
  if (config.shadow) {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
    ctx.shadowBlur = 12;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 4;
  }

  // Stroke
  if (config.strokeColor && config.strokeWidth) {
    ctx.strokeStyle = config.strokeColor;
    ctx.lineWidth = config.strokeWidth;
    ctx.strokeText(config.text, 0, 0);
  }

  // Fill
  ctx.fillStyle = config.color || '#ffffff';
  ctx.fillText(config.text, 0, 0);

  // Reset shadow
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
}

/**
 * Format seconds into HH:MM:SS:FF standard NLE timecode
 */
export function formatTimecode(seconds: number, fps = 30): string {
  const totalFrames = Math.max(0, Math.floor(seconds * fps));
  const f = totalFrames % fps;
  const totalSeconds = Math.floor(totalFrames / fps);
  const s = totalSeconds % 60;
  const totalMinutes = Math.floor(totalSeconds / 60);
  const m = totalMinutes % 60;
  const h = Math.floor(totalMinutes / 60);

  const pad = (num: number, digits = 2) => String(num).padStart(digits, '0');
  return `${pad(h)}:${pad(m)}:${pad(s)}:${pad(f)}`;
}
