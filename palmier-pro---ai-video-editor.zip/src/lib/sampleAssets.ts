import { MediaAsset } from '../types/editor';

// Reliable high quality royalty-free media assets for demo & instant testing
export const INITIAL_ASSETS: MediaAsset[] = [
  {
    id: 'asset-nature-1',
    name: 'Cinematic Mountain Drone.mp4',
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    duration: 15.0,
    width: 1920,
    height: 1080,
    thumbnail: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=320&auto=format&fit=crop&q=60',
    sizeBytes: 12400000,
  },
  {
    id: 'asset-city-2',
    name: 'Cyberpunk Neon City.mp4',
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    duration: 15.0,
    width: 1920,
    height: 1080,
    thumbnail: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=320&auto=format&fit=crop&q=60',
    sizeBytes: 14200000,
  },
  {
    id: 'asset-tech-3',
    name: 'Macro Liquid Flow.mp4',
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    duration: 15.0,
    width: 1920,
    height: 1080,
    thumbnail: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=320&auto=format&fit=crop&q=60',
    sizeBytes: 10800000,
  },
  {
    id: 'asset-vlog-4',
    name: 'Ocean Waves Sunset.mp4',
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    duration: 12.0,
    width: 1920,
    height: 1080,
    thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=320&auto=format&fit=crop&q=60',
    sizeBytes: 9500000,
  },
  // Audio assets
  {
    id: 'asset-audio-lofi',
    name: 'Sunset Lofi Chill Beat.mp3',
    type: 'audio',
    url: 'https://actions.google.com/sounds/v1/water/rain_heavy.ogg',
    duration: 20.0,
    thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=320&auto=format&fit=crop&q=60',
    sizeBytes: 2500000,
  },
  {
    id: 'asset-audio-ambient',
    name: 'Deep Space Drone Ambient.mp3',
    type: 'audio',
    url: 'https://actions.google.com/sounds/v1/ambiences/hum_fluorescent_light.ogg',
    duration: 18.0,
    thumbnail: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=320&auto=format&fit=crop&q=60',
    sizeBytes: 1900000,
  },
  {
    id: 'asset-audio-whoosh',
    name: 'Cinematic Whoosh SFX.mp3',
    type: 'audio',
    url: 'https://actions.google.com/sounds/v1/foley/whoosh_heavy.ogg',
    duration: 3.0,
    thumbnail: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=320&auto=format&fit=crop&q=60',
    sizeBytes: 300000,
  },
  // Image assets
  {
    id: 'asset-img-overlay',
    name: 'Retro Film Grain Glow.png',
    type: 'image',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1280&auto=format&fit=crop&q=80',
    duration: 5.0,
    width: 1920,
    height: 1080,
    thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=320&auto=format&fit=crop&q=60',
    sizeBytes: 850000,
  }
];

// Helper to generate a placeholder canvas data URL for instant offline video fallback or text cards
export function createGradientCanvas(width = 1920, height = 1080, title = 'Sample Title', colorA = '#1e1b4b', colorB = '#3b82f6'): string {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  const grad = ctx.createLinearGradient(0, 0, width, height);
  grad.addColorStop(0, colorA);
  grad.addColorStop(1, colorB);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.font = 'bold 72px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(title, width / 2, height / 2);

  return canvas.toDataURL('image/png');
}
