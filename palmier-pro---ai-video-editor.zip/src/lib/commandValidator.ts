import {
  EditingCommand,
  CommandValidationResult,
  TimelineClip,
  TimelineTrack,
  ProjectSettings,
  MediaAsset,
  SupportedCommandType,
} from '../types/editor';

export const SUPPORTED_COMMAND_TYPES: SupportedCommandType[] = [
  'add_clip',
  'remove_clip',
  'trim_clip',
  'split_clip',
  'move_clip',
  'resize_clip',
  'change_volume',
  'change_speed',
  'add_transition',
  'add_text',
  'add_audio',
  'add_marker',
  'change_aspect_ratio',
  'undo',
  'redo',
];

/**
 * Validates an editing command against the current timeline state.
 * Enforces clip/track reference integrity, bounds, non-negative durations,
 * valid timeline positions, and generates a human-readable preview description.
 */
export function validateCommand(
  rawCmd: any,
  clips: TimelineClip[],
  tracks: TimelineTrack[],
  assets: MediaAsset[],
  settings: ProjectSettings
): CommandValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  let previewDescription = '';

  if (!rawCmd || typeof rawCmd !== 'object') {
    return {
      valid: false,
      command: rawCmd,
      errors: ['Command must be a valid JSON object.'],
      warnings: [],
      previewDescription: 'Invalid command payload',
    };
  }

  // 1. Verify command type
  const type = rawCmd.type as SupportedCommandType;
  if (!SUPPORTED_COMMAND_TYPES.includes(type)) {
    return {
      valid: false,
      command: rawCmd,
      errors: [`Unsupported command type: "${String(rawCmd.type)}". Supported types: ${SUPPORTED_COMMAND_TYPES.join(', ')}`],
      warnings: [],
      previewDescription: `Unsupported command "${String(rawCmd.type)}"`,
    };
  }

  // Helper to find clip by ID or alias
  const resolveClip = (clipId: string): TimelineClip | undefined => {
    if (!clipId) return undefined;
    // Exact match
    const found = clips.find((c) => c.id === clipId);
    if (found) return found;

    // Numerical index or name match fallback
    const lower = clipId.toLowerCase().trim();
    if (lower === 'clip 1' || lower === 'clip_1' || lower === 'first clip' || lower === 'clip_001') {
      return clips[0];
    }
    if (lower === 'clip 2' || lower === 'clip_2' || lower === 'second clip' || lower === 'clip_002') {
      return clips[1];
    }
    if (lower === 'clip 3' || lower === 'clip_3' || lower === 'third clip' || lower === 'clip_003') {
      return clips[2];
    }
    return clips.find((c) => c.name.toLowerCase().includes(lower));
  };

  const sanitizedCmd: any = { type, id: rawCmd.id || `cmd-${Date.now()}-${Math.random().toString(36).slice(2, 6)}` };

  switch (type) {
    case 'add_clip': {
      const startTime = Number(rawCmd.startTime);
      if (isNaN(startTime) || startTime < 0) {
        errors.push(`Invalid start time: "${rawCmd.startTime}". Must be 0 or greater.`);
      } else if (startTime > settings.duration) {
        warnings.push(`Start time (${startTime}s) is beyond current project duration (${settings.duration}s). Project duration will expand.`);
      }
      sanitizedCmd.startTime = Math.max(0, startTime || 0);

      if (rawCmd.duration !== undefined) {
        const dur = Number(rawCmd.duration);
        if (isNaN(dur) || dur <= 0) {
          errors.push(`Invalid clip duration: "${rawCmd.duration}". Duration must be strictly greater than 0.`);
        } else {
          sanitizedCmd.duration = Math.max(0.1, dur);
        }
      } else {
        sanitizedCmd.duration = 5.0;
      }

      if (rawCmd.assetId) {
        const assetExists = assets.some((a) => a.id === rawCmd.assetId);
        if (!assetExists) {
          warnings.push(`Asset ID "${rawCmd.assetId}" not found in media library. A default sample clip will be used.`);
        }
        sanitizedCmd.assetId = rawCmd.assetId;
      }

      if (rawCmd.trackId) {
        const trackExists = tracks.some((t) => t.id === rawCmd.trackId);
        if (!trackExists) {
          warnings.push(`Track ID "${rawCmd.trackId}" not found. Target track will default to first video track.`);
        }
        sanitizedCmd.trackId = rawCmd.trackId;
      }

      sanitizedCmd.name = rawCmd.name ? String(rawCmd.name).slice(0, 80) : undefined;
      previewDescription = `Add clip at ${sanitizedCmd.startTime.toFixed(2)}s (duration: ${sanitizedCmd.duration}s)`;
      break;
    }

    case 'remove_clip': {
      const target = resolveClip(rawCmd.clipId);
      if (!target) {
        errors.push(`Clip reference "${rawCmd.clipId}" does not exist in the current timeline.`);
      } else {
        sanitizedCmd.clipId = target.id;
        previewDescription = `Remove clip "${target.name}" (${target.id}) from timeline`;
      }
      break;
    }

    case 'trim_clip': {
      const target = resolveClip(rawCmd.clipId);
      if (!target) {
        errors.push(`Target clip "${rawCmd.clipId}" not found for trim operation.`);
      } else {
        sanitizedCmd.clipId = target.id;
        let newTrimIn = target.trimIn;
        let newTrimOut = target.trimOut;
        let newStart = target.startTime;

        if (rawCmd.trimIn !== undefined) {
          const val = Number(rawCmd.trimIn);
          if (isNaN(val) || val < 0) {
            errors.push('trimIn must be 0 or greater.');
          } else {
            newTrimIn = val;
          }
        }

        if (rawCmd.trimOut !== undefined) {
          const val = Number(rawCmd.trimOut);
          if (isNaN(val) || val <= newTrimIn) {
            errors.push('trimOut must be greater than trimIn.');
          } else {
            newTrimOut = val;
          }
        }

        if (rawCmd.startTime !== undefined) {
          const val = Number(rawCmd.startTime);
          if (isNaN(val) || val < 0) {
            errors.push('startTime must be 0 or greater.');
          } else {
            newStart = val;
          }
        }

        if (rawCmd.duration !== undefined) {
          const dur = Number(rawCmd.duration);
          if (isNaN(dur) || dur <= 0) {
            errors.push('Trim duration must be strictly greater than 0.');
          } else {
            newTrimOut = newTrimIn + dur * target.speed;
          }
        }

        sanitizedCmd.trimIn = newTrimIn;
        sanitizedCmd.trimOut = newTrimOut;
        sanitizedCmd.startTime = newStart;
        sanitizedCmd.duration = (newTrimOut - newTrimIn) / target.speed;

        previewDescription = `Trim "${target.name}": in=${newTrimIn.toFixed(2)}s, out=${newTrimOut.toFixed(2)}s (duration=${sanitizedCmd.duration.toFixed(2)}s)`;
      }
      break;
    }

    case 'split_clip': {
      const target = resolveClip(rawCmd.clipId);
      if (!target) {
        errors.push(`Target clip "${rawCmd.clipId}" not found for split operation.`);
      } else {
        sanitizedCmd.clipId = target.id;
        const splitTime = rawCmd.splitTime !== undefined ? Number(rawCmd.splitTime) : undefined;
        if (splitTime !== undefined) {
          if (isNaN(splitTime)) {
            errors.push('splitTime must be a valid number.');
          } else if (splitTime <= target.startTime || splitTime >= target.startTime + target.duration) {
            errors.push(
              `Split position (${splitTime.toFixed(2)}s) must be strictly inside the clip boundaries [${target.startTime.toFixed(2)}s - ${(target.startTime + target.duration).toFixed(2)}s].`
            );
          } else {
            sanitizedCmd.splitTime = splitTime;
          }
        }
        previewDescription = `Split "${target.name}" at ${sanitizedCmd.splitTime !== undefined ? sanitizedCmd.splitTime.toFixed(2) + 's' : 'current playhead'}`;
      }
      break;
    }

    case 'move_clip': {
      const target = resolveClip(rawCmd.clipId);
      if (!target) {
        errors.push(`Target clip "${rawCmd.clipId}" not found for move operation.`);
      } else {
        sanitizedCmd.clipId = target.id;
        const startTime = Number(rawCmd.startTime);
        if (isNaN(startTime) || startTime < 0) {
          errors.push(`Invalid start time "${rawCmd.startTime}". Cannot set negative timeline position.`);
        } else {
          sanitizedCmd.startTime = Math.max(0, startTime);
          if (sanitizedCmd.startTime + target.duration > settings.duration) {
            warnings.push(`Clip will extend past current project duration (${settings.duration}s).`);
          }
        }

        if (rawCmd.trackId) {
          const trackExists = tracks.some((t) => t.id === rawCmd.trackId);
          if (!trackExists) {
            warnings.push(`Target track "${rawCmd.trackId}" not found. Keeping current track.`);
          } else {
            sanitizedCmd.trackId = rawCmd.trackId;
          }
        }

        previewDescription = `Move "${target.name}" to ${sanitizedCmd.startTime.toFixed(2)}s${sanitizedCmd.trackId ? ` on track ${sanitizedCmd.trackId}` : ''}`;
      }
      break;
    }

    case 'resize_clip': {
      const target = resolveClip(rawCmd.clipId);
      if (!target) {
        errors.push(`Target clip "${rawCmd.clipId}" not found for resize.`);
      } else {
        sanitizedCmd.clipId = target.id;
        if (rawCmd.duration !== undefined) {
          const dur = Number(rawCmd.duration);
          if (isNaN(dur) || dur <= 0) {
            errors.push(`Duration must be greater than 0.`);
          } else {
            sanitizedCmd.duration = dur;
          }
        }
        if (rawCmd.scale !== undefined) {
          const scale = Number(rawCmd.scale);
          if (isNaN(scale) || scale < 0.1 || scale > 5.0) {
            errors.push('Visual scale must be between 0.1x and 5.0x.');
          } else {
            sanitizedCmd.scale = Math.round(scale * 100) / 100;
          }
        }
        previewDescription = `Resize "${target.name}": ${sanitizedCmd.duration ? `duration=${sanitizedCmd.duration}s` : ''} ${sanitizedCmd.scale ? `scale=${sanitizedCmd.scale}x` : ''}`;
      }
      break;
    }

    case 'change_volume': {
      const target = resolveClip(rawCmd.clipId);
      if (!target) {
        errors.push(`Target clip "${rawCmd.clipId}" not found for volume change.`);
      } else {
        sanitizedCmd.clipId = target.id;
        const vol = Number(rawCmd.volume);
        if (isNaN(vol) || vol < 0 || vol > 2.0) {
          errors.push(`Volume must be between 0.0 (muted) and 2.0 (200%). Received: "${rawCmd.volume}"`);
        } else {
          sanitizedCmd.volume = Math.round(vol * 100) / 100;
          previewDescription = `Set volume of "${target.name}" to ${Math.round(sanitizedCmd.volume * 100)}%`;
        }
      }
      break;
    }

    case 'change_speed': {
      const target = resolveClip(rawCmd.clipId);
      if (!target) {
        errors.push(`Target clip "${rawCmd.clipId}" not found for speed adjustment.`);
      } else {
        sanitizedCmd.clipId = target.id;
        const spd = Number(rawCmd.speed);
        if (isNaN(spd) || spd < 0.25 || spd > 4.0) {
          errors.push(`Playback speed must be between 0.25x and 4.0x. Received: "${rawCmd.speed}"`);
        } else {
          sanitizedCmd.speed = Math.round(spd * 100) / 100;
          previewDescription = `Change speed of "${target.name}" to ${sanitizedCmd.speed}x`;
        }
      }
      break;
    }

    case 'add_transition': {
      const target = resolveClip(rawCmd.clipId);
      if (!target) {
        errors.push(`Target clip "${rawCmd.clipId}" not found for transition.`);
      } else {
        sanitizedCmd.clipId = target.id;
        const allowedTransitions = ['fade', 'dissolve', 'wipe', 'slide', 'zoom'];
        const transType = String(rawCmd.transitionType || 'fade').toLowerCase();
        if (!allowedTransitions.includes(transType)) {
          errors.push(`Unsupported transition type: "${transType}". Allowed: ${allowedTransitions.join(', ')}`);
        } else {
          sanitizedCmd.transitionType = transType;
        }

        const dur = rawCmd.duration !== undefined ? Number(rawCmd.duration) : 1.0;
        if (isNaN(dur) || dur <= 0 || dur > target.duration) {
          errors.push(`Transition duration (${dur}s) must be positive and cannot exceed clip length (${target.duration}s).`);
        } else {
          sanitizedCmd.duration = Math.round(dur * 10) / 10;
        }

        sanitizedCmd.position = ['in', 'out', 'both'].includes(rawCmd.position) ? rawCmd.position : 'both';
        previewDescription = `Add ${sanitizedCmd.transitionType} transition (${sanitizedCmd.duration}s) to "${target.name}"`;
      }
      break;
    }

    case 'add_text': {
      if (!rawCmd.text || typeof rawCmd.text !== 'string') {
        errors.push('Text title content is required.');
      } else {
        sanitizedCmd.text = rawCmd.text.replace(/<[^>]*>?/gm, '').slice(0, 140);
      }

      const startTime = rawCmd.startTime !== undefined ? Number(rawCmd.startTime) : 0;
      if (isNaN(startTime) || startTime < 0) {
        errors.push('startTime must be 0 or greater.');
      } else {
        sanitizedCmd.startTime = startTime;
      }

      const dur = rawCmd.duration !== undefined ? Number(rawCmd.duration) : 4.0;
      if (isNaN(dur) || dur <= 0) {
        errors.push('Duration must be greater than 0.');
      } else {
        sanitizedCmd.duration = dur;
      }

      sanitizedCmd.fontSize = Number(rawCmd.fontSize) || 48;
      sanitizedCmd.color = rawCmd.color ? String(rawCmd.color).slice(0, 32) : '#ffffff';
      sanitizedCmd.backgroundColor = rawCmd.backgroundColor ? String(rawCmd.backgroundColor).slice(0, 32) : 'rgba(0,0,0,0.5)';
      sanitizedCmd.positionY = Number(rawCmd.positionY) || 30;

      previewDescription = `Add text title "${sanitizedCmd.text}" at ${sanitizedCmd.startTime}s (duration: ${sanitizedCmd.duration}s)`;
      break;
    }

    case 'add_audio': {
      const startTime = rawCmd.startTime !== undefined ? Number(rawCmd.startTime) : 0;
      if (isNaN(startTime) || startTime < 0) {
        errors.push('Audio startTime must be 0 or greater.');
      } else {
        sanitizedCmd.startTime = startTime;
      }

      const dur = rawCmd.duration !== undefined ? Number(rawCmd.duration) : 10.0;
      if (isNaN(dur) || dur <= 0) {
        errors.push('Audio duration must be greater than 0.');
      } else {
        sanitizedCmd.duration = dur;
      }

      const vol = rawCmd.volume !== undefined ? Number(rawCmd.volume) : 0.8;
      sanitizedCmd.volume = Math.min(2.0, Math.max(0, isNaN(vol) ? 0.8 : vol));
      sanitizedCmd.assetId = rawCmd.assetId;

      previewDescription = `Add background audio at ${sanitizedCmd.startTime}s (vol: ${Math.round(sanitizedCmd.volume * 100)}%)`;
      break;
    }

    case 'add_marker': {
      const time = Number(rawCmd.time);
      if (isNaN(time) || time < 0 || time > settings.duration) {
        errors.push(`Marker time must be between 0 and project duration (${settings.duration}s). Received: "${rawCmd.time}"`);
      } else {
        sanitizedCmd.time = Math.round(time * 100) / 100;
      }

      sanitizedCmd.label = rawCmd.label ? String(rawCmd.label).slice(0, 50) : `Marker @ ${sanitizedCmd.time}s`;
      sanitizedCmd.color = rawCmd.color ? String(rawCmd.color).slice(0, 20) : '#f43f5e';

      previewDescription = `Place marker "${sanitizedCmd.label}" at ${sanitizedCmd.time}s`;
      break;
    }

    case 'change_aspect_ratio': {
      const allowed = ['16:9', '9:16', '1:1', '4:5', '21:9'];
      if (!allowed.includes(rawCmd.aspectRatio)) {
        errors.push(`Invalid aspect ratio: "${rawCmd.aspectRatio}". Allowed: ${allowed.join(', ')}`);
      } else {
        sanitizedCmd.aspectRatio = rawCmd.aspectRatio;
        previewDescription = `Change canvas aspect ratio to ${sanitizedCmd.aspectRatio}`;
      }
      break;
    }

    case 'undo': {
      previewDescription = 'Undo last editor action';
      break;
    }

    case 'redo': {
      previewDescription = 'Redo previously undone editor action';
      break;
    }

    default:
      errors.push(`Unrecognized command type: "${type}"`);
  }

  return {
    valid: errors.length === 0,
    command: sanitizedCmd as EditingCommand,
    errors,
    warnings,
    previewDescription: previewDescription || `${type} operation`,
  };
}
