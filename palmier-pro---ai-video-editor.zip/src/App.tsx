import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { MediaPanel } from './components/MediaPanel';
import { PreviewPlayer } from './components/PreviewPlayer';
import { Inspector } from './components/Inspector';
import { Timeline } from './components/Timeline';
import { AIAssistant } from './components/AIAssistant';
import { ExportModal } from './components/ExportModal';
import { SettingsModal } from './components/SettingsModal';
import { useEditorStore } from './store/editorStore';

export default function App() {
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(true);

  const {
    togglePlay,
    selectedClipId,
    splitClip,
    deleteClip,
    playhead,
    setPlayhead,
    projectSettings,
    undo,
    redo,
  } = useEditorStore();

  // Keyboard Shortcuts handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when user is typing in an input or textarea
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable
      ) {
        return;
      }

      // Space: Toggle Play/Pause
      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      }

      // S: Split clip at playhead
      if (e.key === 's' || e.key === 'S') {
        if (selectedClipId) {
          e.preventDefault();
          splitClip(selectedClipId, playhead);
        }
      }

      // Delete or Backspace: Delete selected clip
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedClipId) {
          e.preventDefault();
          deleteClip(selectedClipId);
        }
      }

      // Undo: Ctrl/Cmd + Z
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && (e.key === 'z' || e.key === 'Z')) {
        e.preventDefault();
        undo();
      }

      // Redo: Ctrl/Cmd + Shift + Z or Ctrl/Cmd + Y
      if (
        ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'z' || e.key === 'Z')) ||
        ((e.ctrlKey || e.metaKey) && (e.key === 'y' || e.key === 'Y'))
      ) {
        e.preventDefault();
        redo();
      }

      // Frame stepping
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setPlayhead(Math.max(0, playhead - 1 / projectSettings.fps));
      }
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        setPlayhead(Math.min(projectSettings.duration, playhead + 1 / projectSettings.fps));
      }

      // Home & End
      if (e.key === 'Home') {
        e.preventDefault();
        setPlayhead(0);
      }
      if (e.key === 'End') {
        e.preventDefault();
        setPlayhead(projectSettings.duration);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePlay, selectedClipId, splitClip, deleteClip, playhead, projectSettings, undo, redo, setPlayhead]);

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#0a0b0f] text-slate-100 font-sans">
      {/* Top Navigation */}
      <Navbar
        onOpenExport={() => setIsExportOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onToggleAIAssistant={() => setIsAIAssistantOpen(!isAIAssistantOpen)}
        isAIAssistantOpen={isAIAssistantOpen}
      />

      {/* Main Workspace (Middle Row) */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left: Media Library, Assets, Stock, Titles */}
        <MediaPanel />

        {/* Center: Realtime Canvas Player & Preview */}
        <PreviewPlayer />

        {/* Right: Inspector Properties */}
        <Inspector />

        {/* AI Assistant Co-pilot Panel (Can be toggled) */}
        {isAIAssistantOpen && (
          <AIAssistant
            isOpen={isAIAssistantOpen}
            onClose={() => setIsAIAssistantOpen(false)}
          />
        )}
      </div>

      {/* Bottom Multitrack Timeline */}
      <Timeline />

      {/* Modals */}
      <ExportModal isOpen={isExportOpen} onClose={() => setIsExportOpen(false)} />
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    </div>
  );
}
