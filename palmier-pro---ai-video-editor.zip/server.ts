import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import multer from 'multer';
import {
  probeMetadata,
  generateThumbnail,
  generateWaveformPeaks,
  trimVideo,
  concatenateClips,
  mixAudioWithFade,
  startAsyncTimelineExport,
  exportJobs,
  UPLOADS_DIR,
  TEMP_DIR,
  EXPORTS_DIR,
} from './src/server/ffmpegManager';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));

// Multer storage setup for safe uploads
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.mp4';
    const safeName = `upload-${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`;
    cb(null, safeName);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 250 * 1024 * 1024 }, // 250 MB
});

// Initialize Google GenAI
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// ==========================================
// FFMPEG VIDEO PROCESSING ENDPOINTS
// ==========================================

// 1. Upload video / audio with automatic metadata extraction, thumbnail & waveform generation
app.post('/api/ffmpeg/upload', upload.single('media'), async (req, res) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: 'No media file provided.' });
    }

    const filePath = file.path;
    const mediaUrl = `/api/ffmpeg/media/${file.filename}`;

    // Read metadata safely using ffprobe
    let metadata;
    try {
      metadata = await probeMetadata(filePath);
    } catch (e: any) {
      console.warn('Metadata probe fallback:', e.message);
      metadata = {
        duration: 10,
        width: 1920,
        height: 1080,
        fps: 30,
        codec: 'h264',
        bitrate: 5000000,
        sizeBytes: file.size,
        hasAudio: true,
      };
    }

    // Generate thumbnail for video
    let thumbnail: string | undefined;
    const isVideo = file.mimetype.startsWith('video/') || file.originalname.match(/\.(mp4|webm|mov|mkv)$/i);
    if (isVideo) {
      try {
        thumbnail = await generateThumbnail(filePath, Math.min(1.0, metadata.duration / 2));
      } catch (err: any) {
        console.warn('Thumbnail generation failed:', err.message);
      }
    }

    // Generate audio waveform peaks
    let waveform: number[] = [];
    try {
      waveform = await generateWaveformPeaks(filePath, 60);
    } catch (err: any) {
      console.warn('Waveform generation failed:', err.message);
    }

    return res.json({
      success: true,
      asset: {
        id: `asset-up-${Date.now()}`,
        name: file.originalname,
        type: isVideo ? 'video' : file.mimetype.startsWith('audio/') ? 'audio' : 'image',
        url: mediaUrl,
        filePath,
        duration: metadata.duration,
        width: metadata.width,
        height: metadata.height,
        thumbnail,
        waveform,
        sizeBytes: file.size,
        codec: metadata.codec,
      },
    });
  } catch (error: any) {
    console.error('Error in /api/ffmpeg/upload:', error);
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 2. Serve uploaded & processed media files with range request support
app.get('/api/ffmpeg/media/:fileName', (req, res) => {
  const fileName = path.basename(req.params.fileName);
  let filePath = path.join(UPLOADS_DIR, fileName);

  if (!fs.existsSync(filePath)) {
    filePath = path.join(TEMP_DIR, fileName);
  }
  if (!fs.existsSync(filePath)) {
    filePath = path.join(EXPORTS_DIR, fileName);
  }

  if (!fs.existsSync(filePath)) {
    return res.status(404).send('File not found');
  }

  res.sendFile(filePath);
});

// 3. Probe video metadata
app.post('/api/ffmpeg/probe', async (req, res) => {
  try {
    const { filePath } = req.body;
    if (!filePath || !fs.existsSync(filePath)) {
      return res.status(400).json({ error: 'Valid filePath is required.' });
    }
    const meta = await probeMetadata(filePath);
    return res.json({ success: true, metadata: meta });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 4. Generate video thumbnail at specific time
app.post('/api/ffmpeg/thumbnail', async (req, res) => {
  try {
    const { filePath, time, width } = req.body;
    if (!filePath || !fs.existsSync(filePath)) {
      return res.status(400).json({ error: 'Valid filePath is required.' });
    }
    const thumbDataUrl = await generateThumbnail(filePath, time || 1.0, width || 320);
    return res.json({ success: true, thumbnail: thumbDataUrl });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 5. Generate audio waveform peak data
app.post('/api/ffmpeg/waveform', async (req, res) => {
  try {
    const { filePath, samples } = req.body;
    if (!filePath || !fs.existsSync(filePath)) {
      return res.status(400).json({ error: 'Valid filePath is required.' });
    }
    const peaks = await generateWaveformPeaks(filePath, samples || 80);
    return res.json({ success: true, peaks });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 6. Trim video clip
app.post('/api/ffmpeg/trim', async (req, res) => {
  try {
    const { filePath, startTime, duration } = req.body;
    if (!filePath || !fs.existsSync(filePath)) {
      return res.status(400).json({ error: 'Valid filePath is required.' });
    }
    const trimmed = await trimVideo(filePath, Number(startTime) || 0, Number(duration) || 5);
    return res.json({
      success: true,
      fileName: trimmed.fileName,
      url: `/api/ffmpeg/media/${trimmed.fileName}`,
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 7. Concatenate multiple clips
app.post('/api/ffmpeg/concat', async (req, res) => {
  try {
    const { filePaths } = req.body;
    if (!Array.isArray(filePaths) || filePaths.length === 0) {
      return res.status(400).json({ error: 'filePaths array is required.' });
    }
    const result = await concatenateClips(filePaths);
    return res.json({
      success: true,
      fileName: result.fileName,
      url: `/api/ffmpeg/media/${result.fileName}`,
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 8. Mix background audio with volume and fade in/out
app.post('/api/ffmpeg/mix-audio', async (req, res) => {
  try {
    const { videoPath, audioPath, volume, fadeIn, fadeOut, duration } = req.body;
    if (!videoPath || !fs.existsSync(videoPath) || !audioPath || !fs.existsSync(audioPath)) {
      return res.status(400).json({ error: 'Valid videoPath and audioPath are required.' });
    }
    const mixed = await mixAudioWithFade(
      videoPath,
      audioPath,
      Number(volume) || 0.4,
      Number(fadeIn) || 1.0,
      Number(fadeOut) || 1.5,
      Number(duration) || 10.0
    );
    return res.json({
      success: true,
      fileName: mixed.fileName,
      url: `/api/ffmpeg/media/${mixed.fileName}`,
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 9. Start asynchronous timeline master export job
app.post('/api/ffmpeg/export', async (req, res) => {
  try {
    const { timeline } = req.body;
    if (!timeline) {
      return res.status(400).json({ error: 'Timeline configuration is required.' });
    }

    const jobId = await startAsyncTimelineExport(timeline);
    return res.json({
      success: true,
      jobId,
      message: 'Export job initiated successfully.',
    });
  } catch (error: any) {
    console.error('Error starting export job:', error);
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 10. Query export job status & progress
app.get('/api/ffmpeg/export-status/:jobId', (req, res) => {
  const jobId = req.params.jobId;
  const job = exportJobs.get(jobId);

  if (!job) {
    return res.status(404).json({ error: 'Export job not found' });
  }

  return res.json({
    id: job.id,
    status: job.status,
    stage: job.stage,
    progress: job.progress,
    outputFileName: job.outputFileName,
    downloadUrl: job.outputFileName ? `/api/ffmpeg/download/${job.outputFileName}` : null,
    error: job.error,
  });
});

// 11. Download finished master MP4 file
app.get('/api/ffmpeg/download/:fileName', (req, res) => {
  const fileName = path.basename(req.params.fileName);
  const filePath = path.join(EXPORTS_DIR, fileName);

  if (!fs.existsSync(filePath)) {
    return res.status(404).send('Export file not found or expired.');
  }

  res.download(filePath, fileName, (err) => {
    if (err) {
      console.warn('Download error:', err.message);
    }
  });
});

// ==========================================
// DEDICATED AI EDITING COMMAND PARSER
// ==========================================

async function parseEditingCommands(prompt: string, timelineState: any) {
  const systemInstruction = `
You are the expert AI Video Editing Command Parser for "Palmier Pro".
Your sole responsibility is to translate user natural language editing requests into an array of strictly typed JSON editing commands.
NEVER generate or execute arbitrary JavaScript code.
Only output commands from the supported 15 operations:

1. "add_clip":
   { "type": "add_clip", "assetId"?: string, "trackId"?: string, "startTime": number, "duration"?: number, "name"?: string }
2. "remove_clip":
   { "type": "remove_clip", "clipId": string }
3. "trim_clip":
   { "type": "trim_clip", "clipId": string, "trimIn"?: number, "trimOut"?: number, "startTime"?: number, "duration"?: number }
4. "split_clip":
   { "type": "split_clip", "clipId": string, "splitTime"?: number }
5. "move_clip":
   { "type": "move_clip", "clipId": string, "startTime": number, "trackId"?: string }
6. "resize_clip":
   { "type": "resize_clip", "clipId": string, "duration"?: number, "scale"?: number }
7. "change_volume":
   { "type": "change_volume", "clipId": string, "volume": number } (volume range: 0.0 to 2.0, e.g. 0.5 = 50%, 1.0 = 100%)
8. "change_speed":
   { "type": "change_speed", "clipId": string, "speed": number } (speed range: 0.25 to 4.0, e.g. 1.5 = 1.5x)
9. "add_transition":
   { "type": "add_transition", "clipId": string, "transitionType": "fade" | "dissolve" | "wipe" | "slide" | "zoom", "duration"?: number, "position"?: "in" | "out" | "both" }
10. "add_text":
   { "type": "add_text", "text": string, "startTime"?: number, "duration"?: number, "fontSize"?: number, "color"?: string, "backgroundColor"?: string, "positionY"?: number }
11. "add_audio":
   { "type": "add_audio", "assetId"?: string, "startTime"?: number, "duration"?: number, "volume"?: number }
12. "add_marker":
   { "type": "add_marker", "time": number, "label": string, "color"?: string }
13. "change_aspect_ratio":
   { "type": "change_aspect_ratio", "aspectRatio": "16:9" | "9:16" | "1:1" | "4:5" | "21:9" }
14. "undo":
   { "type": "undo" }
15. "redo":
   { "type": "redo" }

Rules:
- Resolve clip references accurately. If user says "clip 2" or "second clip", reference clip index 2's clipId.
- If user says "split clip at current playhead" or "split here", use split_clip with splitTime equal to the playhead time.
- All durations must be positive numbers (> 0).
- All timeline positions (startTime, time) must be non-negative (>= 0).
- Provide a clear, professional explanation in the "explanation" field describing the modification plan.
`;

  const stateSummary = {
    playhead: timelineState?.playhead ?? 0,
    projectDuration: timelineState?.projectDuration ?? 30,
    selectedClipId: timelineState?.selectedClipId ?? null,
    tracks: timelineState?.tracks?.map((t: any) => ({
      id: t.id,
      name: t.name,
      type: t.type,
    })) ?? [],
    clips: timelineState?.clips?.map((c: any, index: number) => ({
      index: index + 1,
      alias: `clip_${String(index + 1).padStart(3, '0')}`,
      id: c.id,
      name: c.name,
      trackId: c.trackId,
      type: c.type,
      startTime: c.startTime,
      duration: c.duration,
      trimIn: c.trimIn,
      trimOut: c.trimOut,
      speed: c.speed,
      volume: c.volume,
    })) ?? [],
    markers: timelineState?.markers ?? [],
    availableAssets: timelineState?.assets?.map((a: any) => ({
      id: a.id,
      name: a.name,
      type: a.type,
      duration: a.duration,
    })) ?? [],
  };

  const userContent = `User Request: "${prompt}"\nCurrent Timeline State:\n${JSON.stringify(stateSummary, null, 2)}`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash',
    contents: userContent,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          explanation: {
            type: Type.STRING,
            description: 'Concise explanation of the editing modifications being performed',
          },
          commands: {
            type: Type.ARRAY,
            description: 'List of validated structured editing operations',
            items: {
              type: Type.OBJECT,
              properties: {
                type: {
                  type: Type.STRING,
                  description: 'Operation type: add_clip, remove_clip, trim_clip, split_clip, move_clip, resize_clip, change_volume, change_speed, add_transition, add_text, add_audio, add_marker, change_aspect_ratio, undo, redo',
                },
                clipId: {
                  type: Type.STRING,
                  description: 'Target clip ID being modified or removed',
                },
                trackId: {
                  type: Type.STRING,
                  description: 'Target track ID',
                },
                assetId: {
                  type: Type.STRING,
                  description: 'Target media asset ID for new clips or audio',
                },
                startTime: {
                  type: Type.NUMBER,
                  description: 'Timeline start position in seconds',
                },
                duration: {
                  type: Type.NUMBER,
                  description: 'Duration in seconds',
                },
                trimIn: {
                  type: Type.NUMBER,
                  description: 'In point trim in seconds',
                },
                trimOut: {
                  type: Type.NUMBER,
                  description: 'Out point trim in seconds',
                },
                splitTime: {
                  type: Type.NUMBER,
                  description: 'Exact timeline split timestamp in seconds',
                },
                scale: {
                  type: Type.NUMBER,
                  description: 'Visual scale factor (0.1 to 5.0)',
                },
                volume: {
                  type: Type.NUMBER,
                  description: 'Audio volume level (0.0 to 2.0)',
                },
                speed: {
                  type: Type.NUMBER,
                  description: 'Playback speed factor (0.25 to 4.0)',
                },
                transitionType: {
                  type: Type.STRING,
                  description: 'Transition effect: fade, dissolve, wipe, slide, zoom',
                },
                text: {
                  type: Type.STRING,
                  description: 'Text string for title cards',
                },
                fontSize: {
                  type: Type.NUMBER,
                  description: 'Font size in px',
                },
                color: {
                  type: Type.STRING,
                  description: 'Hex or CSS color',
                },
                backgroundColor: {
                  type: Type.STRING,
                  description: 'Background color',
                },
                positionY: {
                  type: Type.NUMBER,
                  description: 'Vertical offset position percentage',
                },
                time: {
                  type: Type.NUMBER,
                  description: 'Timestamp for marker placement',
                },
                label: {
                  type: Type.STRING,
                  description: 'Label description for timeline marker',
                },
                aspectRatio: {
                  type: Type.STRING,
                  description: 'Aspect ratio: 16:9, 9:16, 1:1, 4:5, 21:9',
                },
              },
              required: ['type'],
            },
          },
        },
        required: ['explanation', 'commands'],
      },
    },
  });

  const text = response.text;
  if (!text) {
    throw new Error('No response text received from Gemini');
  }

  return JSON.parse(text);
}

// Dedicated AI Command Parsing Endpoint
app.post('/api/ai/parse-command', async (req, res) => {
  try {
    const { prompt, timelineState } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const parsed = await parseEditingCommands(prompt, timelineState);
    return res.json({
      success: true,
      explanation: parsed.explanation,
      commands: parsed.commands || [],
      timestamp: Date.now(),
    });
  } catch (error: any) {
    console.error('Error in /api/ai/parse-command:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to parse AI command',
    });
  }
});

// Backward-compatible edit assistant endpoint
app.post('/api/ai/edit-assistant', async (req, res) => {
  try {
    const { prompt, timelineState } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const parsed = await parseEditingCommands(prompt, timelineState);
    return res.json({
      success: true,
      explanation: parsed.explanation,
      commands: parsed.commands || [],
      plan: {
        id: `plan-${Date.now()}`,
        userPrompt: prompt,
        explanation: parsed.explanation,
        commands: parsed.commands || [],
        timestamp: Date.now(),
      },
    });
  } catch (error: any) {
    console.error('Error in /api/ai/edit-assistant:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to process AI edit assistant request',
    });
  }
});

// System Capabilities endpoint
app.get('/api/system/capabilities', (req, res) => {
  res.json({
    ffmpeg: true,
    ffprobe: true,
    serverGemini: true,
    commandParserVersion: '2.0',
    hardwareAcceleration: true,
    supportedCommands: [
      'add_clip',
      'remove_clip',
      'trim_clip',
      'split_clip',
      'move_clip',
      'resize_clip',
      'change_volume',
      'change_speed',
      'add_transition',
      'add_text',
      'add_audio',
      'add_marker',
      'change_aspect_ratio',
      'undo',
      'redo',
    ],
  });
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        port: 3000,
        host: '0.0.0.0',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Palmier Pro Video Editor running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
